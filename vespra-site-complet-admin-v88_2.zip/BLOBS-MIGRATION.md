# Migration Netlify Forms → Netlify Blobs — Vespra Event

## Ce qui reste dans Netlify Forms

- `devis`
- `reservation`
- `newsletter`

## Ce qui passe dans Netlify Blobs

- produits
- blog
- apparence / thème
- textes
- notices
- avis Google administrés
- planning / réservations du back-office
- suivi des demandes
- logistique
- avis clients publiés et avis en attente
- images et PDF envoyés depuis le back-office

## Procédure

La migration ci-dessous est **une opération initiale, à faire une seule fois**. Après cette migration, les enregistrements du back-office ne repassent plus par Netlify Forms : un clic sur **Enregistrer** écrit directement dans Netlify Blobs et invalide le cache du site. Il n’y a donc **aucune migration à refaire après chaque modification**.


1. Déployer cette version sur le même site Netlify.
2. Vérifier que `NETLIFY_ACCESS_TOKEN`, `ADMIN_USER`, `ADMIN_PASSWORD`, `ADMIN_SECRET`, `AVIS_SECRET` et `RESEND_API_KEY` sont toujours configurés.
3. Ouvrir `/admin/` et se connecter.
4. Cliquer **Migrer vers Blobs**.
5. Vérifier les produits, articles, notices, avis et planning.
6. Une fois la vérification terminée, cliquer **Nettoyer Forms**.
7. Ensuite, pour les modifications courantes (produits, blog, tarifs, textes, etc.), utilisez simplement **Enregistrer** : la donnée est écrite directement dans Blobs et le site est actualisé automatiquement.

Le bouton de nettoyage refuse de supprimer les anciens formulaires si la migration n'a pas laissé un marqueur sans erreur.

Les trois formulaires publics `devis`, `reservation` et `newsletter` ne sont jamais supprimés par ce nettoyage.
