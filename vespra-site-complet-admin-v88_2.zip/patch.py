from pathlib import Path

# admin/index.html
p=Path('/mnt/data/v88_work/admin/index.html')
s=p.read_text()
s=s.replace("<button onclick=\"migrerVersBlobs()\" title=\"À faire une seule fois : copie les anciennes données vers Netlify Blobs\">Migration initiale → Blobs</button><button onclick=\"nettoyerAnciensForms()\" title=\"Après migration vérifiée : supprime les anciens Forms internes\">Nettoyer anciens Forms</button><button onclick=\"toutExporter(this)\">Tout exporter</button>",
            "<button onclick=\"migrerVersBlobs()\" title=\"À faire une seule fois : copie les anciennes données vers Netlify Blobs\">Migration initiale → Blobs</button><button onclick=\"toutExporter(this)\">Tout exporter</button>")
# Remove old cleanup function only; endpoint remains for manual/server compatibility but no UI button.
start=s.find('async function nettoyerAnciensForms(){')
if start!=-1:
    end=s.find('async function migrerVersBlobs(){', start)
    if end!=-1: s=s[:start]+s[end:]
# Make reservation list default to all upcoming rather than only 7 days.
s=s.replace("let filtrePeriode = 'semaine';", "let filtrePeriode = 'tout';")
s=s.replace('<option value="semaine" selected>Cette semaine</option>\n          <option value="tout">Toutes les réservations</option>', '<option value="semaine">Cette semaine</option>\n          <option value="tout" selected>Toutes les réservations</option>')
p.write_text(s)

# reservation.html: fix settings page and broken override
p=Path('/mnt/data/v88_work/admin/reservation.html')
s=p.read_text()
old="""function settingsPage(){
  settingsTab='clients';
  var PANEL='background:#fff;border:1px solid #eee8dc;border-radius:14px;padding:24px';
  var clientsHtml='<div id=\"stab-content-clients\">'
    +'<div style=\"display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;gap:12px;flex-wrap:wrap\">'
    +'<div><div style=\"font:600 15px Poppins;color:var(--navy)\">Base de données clients</div><div style=\"font:12px Inter;color:var(--ink);margin-top:4px\">Les clients existants ont été repris depuis les réservations et sont maintenant conservés dans Netlify Blobs.</div></div>'
    +'<input id=\"client-search\" placeholder=\"Rechercher...\" style=\"border:1px solid #dcd5c8;border-radius:9px;padding:7px 12px;font:13px Inter;width:200px\">'
    +'</div>'
    +'<table class=\"client-table\"><thead><tr><th>Client</th><th>Téléphone</th><th>Email</th><th>Résa</th><th></th></tr></thead>'
    +'<tbody id=\"clients-tbody\"></tbody></table></div>';
  main.innerHTML='<div class=\"page\"><div class=\"pt\">Paramètres</div><div style=\"'+PANEL+'\">'+clientsHtml+'</div></div>';
  renderClientsTable('');
}"""
new="""function settingsPage(){
  settingsTab='clients';
  var PANEL='background:#fff;border:1px solid #eee8dc;border-radius:14px;padding:24px';
  var clientsHtml='<div id=\"stab-content-clients\">'
    +'<div style=\"display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;gap:12px;flex-wrap:wrap\">'
    +'<div><div style=\"font:600 15px Poppins;color:var(--navy)\">Base de données clients</div><div style=\"font:12px Inter;color:var(--ink);margin-top:4px\">Les clients existants ont été repris depuis les réservations et sont maintenant conservés dans Netlify Blobs.</div></div>'
    +'<input id=\"client-search\" placeholder=\"Rechercher...\" style=\"border:1px solid #dcd5c8;border-radius:9px;padding:7px 12px;font:13px Inter;width:200px\">'
    +'</div>'
    +'<table class=\"client-table\"><thead><tr><th>Client</th><th>Téléphone</th><th>Email</th><th>Résa</th><th></th></tr></thead>'
    +'<tbody id=\"clients-tbody\"></tbody></table></div>';
  var adminHtml='<div id=\"stab-content-admin\" style=\"display:none\">'
    +'<div style=\"font:600 15px Poppins;color:var(--navy);margin-bottom:6px\">Compte administrateur</div>'
    +'<div style=\"font:12px Inter;color:var(--ink);line-height:1.55;margin-bottom:18px\">Modifiez ici l’identifiant et le mot de passe utilisés pour accéder au back-office. Le mot de passe n’est jamais affiché ni stocké en clair.</div>'
    +'<div class=\"auth-field\"><label>Identifiant administrateur</label><input id=\"settings-admin-user\" autocomplete=\"username\" placeholder=\"administrateur\"></div>'
    +'<div class=\"auth-field\"><label>Nouveau mot de passe</label><input id=\"settings-admin-password\" type=\"password\" autocomplete=\"new-password\" placeholder=\"8 caractères minimum\"></div>'
    +'<div class=\"auth-field\"><label>Confirmer le mot de passe</label><input id=\"settings-admin-password2\" type=\"password\" autocomplete=\"new-password\" placeholder=\"Retapez le mot de passe\"></div>'
    +'<div id=\"settings-admin-status\" style=\"font:12px Inter;color:var(--ink);margin:8px 0 14px\"></div>'
    +'<button class=\"btn primary\" type=\"button\" onclick=\"saveReservationAdminSettings()\">Enregistrer les identifiants</button></div>';
  var tabs='<div style=\"display:flex;gap:8px;margin-bottom:20px\">'
    +'<button class=\"stab active\" id=\"stab-clients\" onclick=\"switchSettingsTab(\\'clients\\')\">Base clients</button>'
    +'<button class=\"stab\" id=\"stab-admin\" onclick=\"switchSettingsTab(\\'admin\\')\">Admin</button></div>';
  main.innerHTML='<div class=\"page\"><div class=\"pt\">Paramètres</div><div style=\"'+PANEL+'\">'+tabs+clientsHtml+adminHtml+'</div></div>';
  renderClientsTable('');
  var search=document.getElementById('client-search');
  if(search) search.oninput=function(){renderClientsTable(this.value||'');};
}"""
if old not in s:
    raise SystemExit('settingsPage block not found')
s=s.replace(old,new)
# Replace broken final override that forced clients every time.
old2="""// Mise à jour switchSettingsTab pour la page pleine
window.switchSettingsTab=function(tab){
  settingsTab='clients';
  var btn=document.getElementById('stab-clients');var cnt=document.getElementById('stab-content-clients');
  if(btn)btn.classList.add('active');
  if(cnt)cnt.style.display='block';
  renderClientsTable('');
};
"""
new2="""// Onglets Paramètres de la page pleine : Base clients + Admin.
window.switchSettingsTab=function(tab){
  settingsTab=tab;
  ['clients','admin'].forEach(function(t){
    var btn=document.getElementById('stab-'+t),cnt=document.getElementById('stab-content-'+t);
    if(btn)btn.classList.toggle('active',t===tab);
    if(cnt)cnt.style.display=t===tab?'block':'none';
  });
  if(tab==='clients') renderClientsTable(document.getElementById('client-search')?.value||'');
  if(tab==='admin') loadReservationAdminSettings();
};
"""
if old2 not in s:
    raise SystemExit('switch override not found')
s=s.replace(old2,new2)
p.write_text(s)

# Catalogue: canonical category and card behavior. Entire card opens product; small + opens popup.
p=Path('/mnt/data/v88_work/catalogue.html')
s=p.read_text()
s=s.replace("{id:'p22',cat:'Animation',cats:['Animation','Effets spéciaux'],", "{id:'p22',cat:'Lumière et effets',cats:['Lumière et effets','Effets spéciaux'],")
# p21 stays both categories, explicitly retain machine à bulles in Effets spéciaux.
s=s.replace("{id:'p21',cat:'Lumière et effets',cats:['Lumière et effets','Effets spéciaux'],name:'Pyrotechnie'", "{id:'p21',cat:'Lumière et effets',cats:['Lumière et effets','Effets spéciaux'],name:'Machine à bulles & à fumée'")
# Replace card click special-case.
s=s.replace("el.addEventListener('click',()=>{if(p.id==='p22')openPowderPicker();else window.location.href=p.page});", "el.addEventListener('click',()=>{if(p.page)window.location.href=p.page});")
# Ensure p22 + button is visible and popup only from +; existing markup already does this.
p.write_text(s)

# Homepage: canon category, remove +/cross from bestseller canon card, keep card navigation arrow behavior by card click.
p=Path('/mnt/data/v88_work/index.html')
s=p.read_text()
s=s.replace('{id:"p22",cat:"Animation",cats:["Animation","Effets spéciaux"],', '{id:"p22",cat:"Lumière et effets",cats:["Lumière et effets","Effets spéciaux"],')
# In the bestsellers cards, remove the add button only for p22 and add a visible arrow matching the cards' navigation.
old='''<div class="bc-body"><div class="bc-cat">${p.cat}</div><div class="bc-name">${p.name}</div><div class="bc-desc">${p.desc}</div><div class="bc-foot"><div class="bc-price"><span class="bc-from">À partir de</span>${p.price} €</div><button class="bc-add" onclick="event.stopPropagation();handleAdd('${p.id}')">+</button></div></div>`;'''
new='''<div class="bc-body"><div class="bc-cat">${p.cat}</div><div class="bc-name">${p.name}</div><div class="bc-desc">${p.desc}</div><div class="bc-foot"><div class="bc-price"><span class="bc-from">À partir de</span>${p.price} €</div>${p.id==='p22'?'<span class="bc-card-arrow" aria-hidden="true">→</span>':'<button class="bc-add" onclick="event.stopPropagation();handleAdd(\\''+p.id+'\\')">+</button>'}</div></div>`;'''
# The above replacement is tricky due template quoting; use a direct exact replacement with escaped JS.
if old not in s:
    raise SystemExit('bests card markup not found')
s=s.replace(old, new)
# Add style for arrow if not present.
needle='.bc-add:hover{background:var(--navy-h);transform:scale(1.1)}'
s=s.replace(needle, needle+'\n.bc-card-arrow{display:flex;align-items:center;justify-content:center;width:36px;height:36px;color:var(--navy);font-size:25px;font-weight:500;flex-shrink:0}')
p.write_text(s)

# Product page: category tag + robust modal mount hard fix (in case parent styling/DOM breaks it).
p=Path('/mnt/data/v88_work/produit-canons-poudre.html')
s=p.read_text()
s=s.replace('<div class="prod-cat-tag">Animation · Effets spéciaux</div>', '<div class="prod-cat-tag">Lumière et effets · Effets spéciaux</div>')
# Make second product gallery image the contextual gender reveal photo again.
s=s.replace("const PG_IMGS=[{s:'canon-poudre-electrique.webp',a:'Canons à poudre électriques déclenchés lors d’un événement'},{s:'canon-poudre-electrique.webp',a:'Canons à poudre électriques — structure sur fond blanc'}];", "const PG_IMGS=[{s:'canon-poudre-electrique.webp',a:'Canons à poudre électriques sur fond blanc'},{s:'canon-poudre-gender-reveal.webp',a:'Canons à poudre électriques lors d’un événement'}];")
# Ensure hard-fix exists (it already does); enhance it to mount before opening and handle close.
if 'id="powder-picker-hard-fix-js"' not in s:
    s=s.replace('</body>', '''<script id="powder-picker-hard-fix-js">\n(function(){\n  function modal(){return document.getElementById('powderPicker');}\n  function mount(){var m=modal();if(m&&m.parentElement!==document.body)document.body.appendChild(m);return m;}\n  window.openPowderPicker=function(){var m=mount();if(!m)return;document.querySelectorAll('select[name="powder-slot"]').forEach(function(x){x.value='';});if(window.powderSlotsChanged)window.powderSlotsChanged();m.hidden=false;m.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';};\n  window.closePowderPicker=function(){var m=modal();if(!m)return;m.hidden=true;m.setAttribute('aria-hidden','true');document.body.style.overflow='';};\n  document.addEventListener('click',function(e){var c=e.target&&e.target.closest&&e.target.closest('.powder-picker-close');if(c){e.preventDefault();e.stopPropagation();window.closePowderPicker();return;}var m=modal();if(m&&e.target===m){e.preventDefault();window.closePowderPicker();}},true);\n  document.addEventListener('keydown',function(e){if(e.key==='Escape')window.closePowderPicker();});\n})();\n</script></body>''')
p.write_text(s)

# Add explicit canonical redirect for the canon product URL.
p=Path('/mnt/data/v88_work/_redirects')
s=p.read_text()
marker='# ── 1. FICHES PRODUIT REGROUPÉES ────────────────────────────\n'
if '/produit-canons-poudre' not in s:
    s=s.replace(marker, marker+'/produit-canons-poudre          /produit-canons-poudre.html       200\n/produit-canons-poudre/         /produit-canons-poudre.html       200\n\n')
p.write_text(s)
