/* ═══════════════════════════════════════════════════════════════════
   BACK-OFFICE VESPRA EVENT — produits, blog, avis
   ───────────────────────────────────────────────────────────────────
   Un seul fichier, sur le même principe que avis.mjs : aucune base de
   données externe. Les produits et articles de blog sont stockés comme
   des soumissions du formulaire Netlify "produits-admin" / "blog-admin"
   (déclarés en formulaires cachés dans merci.html pour que Netlify les
   détecte au déploiement). Les avis ajoutés depuis l'admin sont publiés
   directement dans "avis-valides", le même formulaire que celui utilisé
   par le lien de validation envoyé par e-mail.

   Connexion : un identifiant (variable Netlify ADMIN_USER) et un mot de
   passe (variable Netlify ADMIN_PASSWORD) donnent un cookie de session
   signé (HMAC, variable ADMIN_SECRET), valable 12h. Aucun identifiant ni
   mot de passe n'est écrit dans ce fichier : tout vient des variables
   d'environnement Netlify.

   Routes (toutes préfixées /api/admin/... via _redirects) :
     POST   /login                          { user, password } → cookie
     GET    /session                        vérifie le cookie
     POST   /logout
     GET    /data?collection=produits|blog  liste (protégé)
     POST   /data                           { collection, item } upsert (protégé)
     DELETE /data?collection=...&id=...     supprime (protégé)
     POST   /avis                           { produit, nom, note, texte } publie direct (protégé)

   Routes publiques (lues par le site, sans authentification) :
     GET /api/produits   → JSON des produits (dernier envoi par id)
     GET /api/blog       → JSON des articles (dernier envoi par id)
     GET /api/theme      → JSON de l'apparence (couleurs, polices, taille)
     GET /api/textes?page=… → textes réécrits pour cette page
     GET /api/notices?page=… → notices masquées ou ajoutées
   ═══════════════════════════════════════════════════════════════════ */

import { createHmac, timingSafeEqual, createHash, randomUUID, randomBytes, scryptSync } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const COOKIE_NAME = 'vespra_admin';
const SESSION_HOURS = 12;

const PRODUCT_FORM = 'produits-admin';
const BLOG_FORM = 'blog-admin';
const AVIS_FORM = 'avis-valides';
const THEME_FORM = 'theme-admin';
const TEXTE_FORM = 'textes-admin';
const GOOGLE_FORM = 'google-admin';
const NOTICE_FORM = 'notices-admin';
const FICHIER_FORM = 'fichiers-admin';
/* Réservations : le planning et sa configuration, enregistrés côté serveur
   pour être les mêmes depuis le téléphone et depuis l'ordinateur. */
const RESA_FORM = 'reservations-admin';
/* Demandes de devis : le formulaire public « reservation » contient les
   demandes elles-mêmes ; ce formulaire-ci ne stocke que leur suivi
   (nouvelle / en cours / validée) sans toucher à la demande d'origine. */
const SUIVI_FORM = 'suivi-demandes-admin';
/* Suivi logistique : où en est le matériel de chaque réservation
   (à préparer, préparé, remis au client, rendu). Enregistré à part pour
   ne jamais entrer en conflit avec la réservation elle-même. */
const LOGISTIQUE_FORM = 'logistique-admin';
/* Le formulaire public dans lequel arrivent les demandes de devis du site. */
const DEMANDE_FORM = 'reservation';

const DATA_STORE = 'vespra-admin-data';
const MEDIA_STORE = 'vespra-media';
const REVIEW_STORE = 'vespra-reviews';
const CLIENT_STORE = 'vespra-clients';
const AUTH_STORE = 'vespra-auth';

function hashAdminPassword(password, salt = randomBytes(16).toString('hex')) {
  const hash = scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function verifyAdminPassword(password, record) {
  if (!record?.hash || !record?.salt) return false;
  const hash = scryptSync(String(password), record.salt, 64).toString('hex');
  return safeEqual(hash, record.hash);
}
async function getAdminOverride() {
  try {
    return await blobStore(AUTH_STORE).get('credentials', { type: 'json', consistency: 'strong' });
  } catch { return null; }
}
async function getEffectiveCredentials() {
  const base = { username: process.env.ADMIN_USER || '', password: process.env.ADMIN_PASSWORD || '' };
  const override = await getAdminOverride();
  return override?.username && override?.passwordRecord
    ? { username: override.username, passwordRecord: override.passwordRecord, overridden: true }
    : { ...base, overridden: false };
}
const INTERNAL_FORMS = new Set([
  PRODUCT_FORM, BLOG_FORM, AVIS_FORM, THEME_FORM, TEXTE_FORM, GOOGLE_FORM,
  NOTICE_FORM, RESA_FORM, SUIVI_FORM, LOGISTIQUE_FORM, FICHIER_FORM,
]);

/* collection appelée par le back-office → formulaire Netlify correspondant */
const COLLECTIONS = {
  produits: PRODUCT_FORM,
  blog: BLOG_FORM,
  theme: THEME_FORM,
  textes: TEXTE_FORM,
  google: GOOGLE_FORM,
  notices: NOTICE_FORM,
  reservations: RESA_FORM,
  suivi: SUIVI_FORM,
  logistique: LOGISTIQUE_FORM,
};
const formDe = (c) => Object.prototype.hasOwnProperty.call(COLLECTIONS, c) ? COLLECTIONS[c] : null;

/* ───────────────────────── utilitaires signature ───────────────────────── */
function sign(payload, secret) {
  return createHmac('sha256', secret).update(payload).digest('hex');
}
function safeEqual(a, b) {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  return A.length === B.length && timingSafeEqual(A, B);
}
function makeSessionToken(secret) {
  const exp = Date.now() + SESSION_HOURS * 3600 * 1000;
  const payload = `admin.${exp}`;
  return `${payload}.${sign(payload, secret)}`;
}
function verifySessionToken(token, secret) {
  if (!token) return false;
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [who, expStr, sig] = parts;
  if (who !== 'admin') return false;
  const exp = parseInt(expStr, 10);
  if (!exp || Date.now() > exp) return false;
  const payload = `${who}.${expStr}`;
  return safeEqual(sign(payload, secret), sig);
}
function getCookie(request, name) {
  const header = request.headers.get('cookie') || '';
  const m = header.match(new RegExp(`(?:^|;\\s*)${name}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : null;
}

/* ───────────────────────── réponses JSON ─────────────────────────
   Deux sortes de réponses :
   - json()        : jamais mise en cache (back-office, données privées)
   - jsonPublic()  : mise en cache par le CDN de Netlify.

   C'est ce second point qui compte pour la facture. Sans cache, chaque
   visiteur de chaque page déclenchait un appel de fonction, et chaque
   appel interrogeait l'API Netlify : c'est ce qui consomme des crédits,
   bien plus que vos modifications. Avec le cache, la réponse est servie
   directement par le CDN sans réveiller la fonction. La directive
   « durable » partage ce cache entre tous les serveurs de Netlify.

   Le cache est vidé à chaque enregistrement depuis le back-office
   (voir viderCache), donc une modification reste visible tout de suite. */
const CACHE_TAG = 'vespra-contenu';
const jsonPublic = (data) =>
  new Response(JSON.stringify(data), {
    status: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'public, max-age=120',
      'netlify-cdn-cache-control': 'public, durable, max-age=3600, stale-while-revalidate=86400',
      'netlify-cache-tag': CACHE_TAG,
    },
  });

/* ───────────────────────── réponses JSON ───────────────────────── */
const json = (data, status = 200, extraHeaders = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extraHeaders },
  });

/* ───────────────────────── accès à l'API Netlify ───────────────────────── */
async function netlifyApi(path, opts = {}) {
  const token = process.env.NETLIFY_ACCESS_TOKEN;
  if (!token) throw new Error('NETLIFY_ACCESS_TOKEN absent');
  const r = await fetch(`https://api.netlify.com/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${token}`, ...(opts.headers || {}) },
  });
  if (!r.ok) throw new Error(`API Netlify ${r.status} sur ${path}`);
  const ct = r.headers.get('content-type') || '';
  return ct.includes('json') ? r.json() : null;
}

let _siteId = null;
async function siteId() {
  if (_siteId) return _siteId;
  if (process.env.SITE_ID) return (_siteId = process.env.SITE_ID);
  const host = (process.env.URL || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
  if (host) {
    try { const site = await netlifyApi(`/sites/${host}`); if (site?.id) return (_siteId = site.id); } catch {}
  }
  throw new Error('SITE_ID absent ou site introuvable');
}

/* Netlify ne rend les soumissions que par pages. Une seule page suffisait
   au début, mais chaque modification ajoute une soumission : au-delà de la
   première page, les enregistrements les plus anciens disparaissaient de la
   lecture — et donc du site et du planning — alors qu'ils existaient
   toujours. On parcourt maintenant toutes les pages.

   La limite de sécurité (25 pages, soit 5 000 soumissions) évite qu'une
   erreur de pagination ne fasse tourner la fonction indéfiniment. */
const PAR_PAGE = 200;
const PAGES_MAX = 25;

async function netlifyFormSubmissions(formName) {
  const forms = await netlifyApi(`/sites/${await siteId()}/forms`);
  const form = forms.find((f) => f.name === formName);
  if (!form) return { form: null, subs: [] };
  const subs = [];
  const vus = new Set();
  for (const etat of ['', 'spam']) {
    for (let page = 1; page <= PAGES_MAX; page++) {
      let lot;
      try {
        lot = await netlifyApi(`/forms/${form.id}/submissions?per_page=${PAR_PAGE}&page=${page}` +
                               (etat ? `&state=${etat}` : ''));
      } catch { break; }
      if (!Array.isArray(lot) || !lot.length) break;
      for (const sub of lot) {
        if (vus.has(sub.id)) continue;
        vus.add(sub.id);
        subs.push(sub);
      }
      if (lot.length < PAR_PAGE) break;
    }
  }
  return { form, subs };
}

async function blobStore(name = DATA_STORE) {
  return getStore(name);
}
function blobKey(collection, id) {
  return `${collection}/${encodeURIComponent(String(id))}`;
}
async function blobItems(collection) {
  const store = await blobStore();
  const { blobs } = await store.list({ prefix: `${collection}/` });
  const items = [];
  for (const b of blobs) {
    try {
      const data = await store.get(b.key, { type: 'json', consistency: 'strong' });
      if (data && typeof data === 'object') {
        items.push({
          id: String(data.id || decodeURIComponent(b.key.slice(collection.length + 1))),
          data,
          created_at: data._created || new Date().toISOString(),
          idKey: b.key,
        });
      }
    } catch (e) {
      console.error('Lecture Blob impossible :', b.key, e.message);
    }
  }
  return { form: { name: collection, blobs: true }, subs: items };
}

async function formSubmissions(formName) {
  if (INTERNAL_FORMS.has(formName)) {
    if (formName === AVIS_FORM) {
      const store = await blobStore(REVIEW_STORE);
      const { blobs } = await store.list({ prefix: 'published/' });
      const subs = [];
      for (const b of blobs) {
        const d = await store.get(b.key, { type: 'json', consistency: 'strong' });
        if (d) subs.push({ id: b.key, data: d, created_at: d._created || new Date().toISOString() });
      }
      return { form: { name: formName, blobs: true }, subs };
    }
    const collection = Object.keys(COLLECTIONS).find(k => COLLECTIONS[k] === formName) || formName;
    return blobItems(collection);
  }
  return netlifyFormSubmissions(formName);
}

async function saveBlobItem(collection, item, secret) {
  const store = await blobStore();
  const clean = cleanFields(item);
  clean.id = String(item.id);
  clean._created = item._created || new Date().toISOString();
  if (secret) clean.sig = item.sig || itemSignature(clean, secret);
  await store.set(blobKey(collection, clean.id), JSON.stringify(clean), {
    metadata: { updatedAt: new Date().toISOString(), collection, id: clean.id },
  });
  return clean;
}

async function deleteBlobItem(collection, id) {
  const store = await blobStore();
  await store.delete(blobKey(collection, id));
}

async function savePublishedReview(review) {
  const store = await blobStore(REVIEW_STORE);
  const base = {
    p: String(review.p || '').slice(0, 200),
    n: String(review.n || '').slice(0, 200),
    s: String(Math.max(1, Math.min(5, parseInt(review.s, 10) || 5))),
    t: String(review.t || '').slice(0, 900),
    d: String(review.d || ''),
    _created: review._created || new Date().toISOString(),
  };
  const hash = createHash('sha256').update(`${base.p}|${base.n}|${base.t}`).digest('hex').slice(0, 24);
  await store.set(`published/${hash}`, JSON.stringify(base));
  return base;
}

async function deletePublishedReview(nom, texte) {
  const store = await blobStore(REVIEW_STORE);
  const { blobs } = await store.list({ prefix: 'published/' });
  for (const b of blobs) {
    const d = await store.get(b.key, { type: 'json', consistency: 'strong' });
    if (d && d.n === nom && d.t === texte) {
      await store.delete(b.key);
      return true;
    }
  }
  return false;
}

async function savePendingReview(review) {
  const store = await blobStore(REVIEW_STORE);
  const id = randomUUID();
  const data = { ...review, id, _created: new Date().toISOString(), status: 'pending' };
  await store.set(`pending/${id}`, JSON.stringify(data));
  return data;
}

/* ── Nettoyage des versions périmées ────────────────────────────────
   Chaque modification ajoute une soumission plutôt que d'en remplacer une :
   c'est ce qui rend l'historique possible, mais dix modifications d'une même
   réservation laissent dix enregistrements alors qu'un seul fait foi.

   On supprime donc les versions dépassées — jamais la version courante, qui
   vient d'être lue et dont on connaît l'identifiant exact. Le nettoyage ne
   se déclenche qu'à partir d'une accumulation réelle, et il est plafonné
   pour que la page ne devienne jamais lente à cause de lui.

   Une suppression qui échoue n'a aucune conséquence : la version courante
   reste en place et le nettoyage sera retenté plus tard.
   ─────────────────────────────────────────────────────────────────── */
const NETTOYAGE_SEUIL = 40;    /* en dessous, ça n'en vaut pas la peine */
const NETTOYAGE_MAX = 60;      /* suppressions par appel */

async function nettoyerVersionsPerimees() {
  return 0;
}

/* dernière soumission par id = version actuelle */
function latestById(subs) {
  const byId = new Map();
  for (const s of subs) {
    const d = s.data || {};
    if (!d.id) continue;
    const existing = byId.get(d.id);
    if (!existing || new Date(s.created_at) > new Date(existing._created)) {
      byId.set(d.id, { ...d, _submissionId: s.id, _created: s.created_at });
    }
  }
  return [...byId.values()].sort((a, b) => new Date(b._created) - new Date(a._created));
}

/* ── Signature du contenu ──────────────────────────────────────────────
   Les formulaires Netlify acceptent par nature n'importe quel envoi venant
   de n'importe où : sans protection, un inconnu qui devine le nom du
   formulaire pourrait publier un produit ou un article sur le site.
   Chaque enregistrement écrit par l'admin porte donc une signature HMAC
   calculée avec ADMIN_SECRET, et le site public n'affiche QUE les
   enregistrements dont la signature est valide. Un envoi non signé (ou
   signé avec la mauvaise clé) est stocké mais jamais affiché.
   ────────────────────────────────────────────────────────────────────── */
const SIG_IGNORE = new Set(['sig', 'bot-field', 'form-name']);

function canonical(fields) {
  const entries = Object.entries(fields)
    .filter(([k, v]) => !SIG_IGNORE.has(k) && !k.startsWith('_') && v !== undefined && v !== null && v !== '')
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => [k, String(v)]);
  return JSON.stringify(entries);
}
function itemSignature(fields, secret) {
  return sign(canonical(fields), secret);
}
function itemSignatureValid(item, secret) {
  if (!secret || !item || !item.sig) return false;
  return safeEqual(itemSignature(item, secret), item.sig);
}

/* ne garde que les champs réellement renseignés : ce qui est signé doit
   être exactement ce que Netlify nous rendra à la relecture */
function cleanFields(fields) {
  const out = {};
  for (const [k, v] of Object.entries(fields)) {
    if (SIG_IGNORE.has(k) || k.startsWith('_')) continue;
    if (v === undefined || v === null) continue;
    const s = String(v);
    if (s === '') continue;
    out[k] = s;
  }
  return out;
}

async function submitToForm(formName, fields, secret) {
  if (INTERNAL_FORMS.has(formName)) {
    if (formName === AVIS_FORM) {
      await savePublishedReview(fields);
      return;
    }
    const collection = Object.keys(COLLECTIONS).find(k => COLLECTIONS[k] === formName);
    if (!collection) throw new Error(`Collection Blobs introuvable pour ${formName}`);
    await saveBlobItem(collection, fields, secret);
    return;
  }
  const siteUrl = process.env.URL;
  if (!siteUrl) throw new Error('URL du site (process.env.URL) absente');
  const clean = cleanFields(fields);
  if (secret) clean.sig = itemSignature(clean, secret);
  const body = new URLSearchParams({ 'form-name': formName, ...clean, 'bot-field': '' });
  const r = await fetch(siteUrl + '/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!r.ok) throw new Error(`Envoi au formulaire ${formName} refusé (${r.status})`);
}

/* Vide le cache du CDN pour que la modification soit visible aussitôt.
   Sans cela, il faudrait attendre l'expiration du cache. */
async function viderCache() {
  try {
    const token = process.env.NETLIFY_ACCESS_TOKEN;
    /* sans jeton, le CDN garde l'ancienne version jusqu'à expiration : la
       modification est bien enregistrée, mais invisible pendant un temps.
       Le back-office le dit clairement plutôt que de laisser croire à une
       panne. */
    if (!token) return 'jeton-absent';
    const r = await fetch('https://api.netlify.com/api/v1/purge', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ site_id: await siteId(), cache_tags: [CACHE_TAG] }),
    });
    return r.ok ? 'vide' : 'refus';
  } catch (e) { console.error('Vidage du cache impossible :', e.message); return 'erreur'; }
}

async function deleteAllSubmissionsWithId(formName, id) {
  if (INTERNAL_FORMS.has(formName)) {
    if (formName === AVIS_FORM) return 0;
    const collection = Object.keys(COLLECTIONS).find(k => COLLECTIONS[k] === formName);
    if (!collection) return 0;
    await deleteBlobItem(collection, id);
    return 1;
  }
  const { subs } = await netlifyFormSubmissions(formName);
  const toDelete = subs.filter((s) => (s.data || {}).id === id);
  for (const s of toDelete) {
    try { await netlifyApi(`/submissions/${s.id}`, { method: 'DELETE' }); } catch (e) { console.error('Suppression impossible :', e.message); }
  }
  return toDelete.length;
}

/* ═══════════════════════════════════════════════════════════════════ */
export default async (request) => {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/admin/, '').replace(/\/$/, '') || '/';
  const secret = process.env.ADMIN_SECRET || process.env.ADMIN_PASSWORD || '';
  const password = process.env.ADMIN_PASSWORD;
  const username = process.env.ADMIN_USER;

  /* ---- routes publiques (pas d'auth), utilisées par le site ----
     Seuls les enregistrements correctement signés sont renvoyés : un envoi
     déposé directement sur le formulaire Netlify par un tiers ne peut pas
     apparaître sur le site. */
  /* ── Tout ce dont une page a besoin, en un seul appel ──────────────
     Chaque page appelait jusqu'à cinq adresses différentes (thème, textes,
     notices, produits, avis Google). Autant d'allers-retours pour le
     visiteur, autant de requêtes facturées, et une page plus lente.

     Cette adresse renvoie l'ensemble d'un coup, pour la page demandée. Elle
     est mise en cache par le CDN comme les autres et vidée à chaque
     modification : au-delà du premier visiteur, la fonction ne tourne même
     pas. Les anciennes adresses restent en service pour ne rien casser.
     ─────────────────────────────────────────────────────────────────── */
  if (url.pathname === '/api/site') {
    const pg = url.searchParams.get('page') || '';
    const valides = (items) => items.filter((x) => itemSignatureValid(x, secret));
    const nettoyer = (items) => items.map(({ sig, _submissionId, _created, ...rest }) => rest);

    try {
      const [theme, textes, notices, produits, google] = await Promise.all([
        formSubmissions(THEME_FORM).then(({ subs }) => subs),
        formSubmissions(TEXTE_FORM).then(({ subs }) => subs),
        formSubmissions(NOTICE_FORM).then(({ subs }) => subs),
        formSubmissions(PRODUCT_FORM).then(({ subs }) => subs),
        formSubmissions(GOOGLE_FORM).then(({ subs }) => subs),
      ]);

      return jsonPublic({
        theme: nettoyer(valides(latestById(theme)
          .filter((x) => x.id === 'theme' && x.action !== 'supprimer')))
          .map(({ id, ...rest }) => rest)[0] || {},
        textes: nettoyer(valides(latestById(textes)
          .filter((x) => x.action !== 'supprimer')
          .filter((x) => !pg || x.page === pg))),
        notices: nettoyer(valides(latestById(notices)
          .filter((x) => !pg || x.page === pg))),
        produits: nettoyer(valides(latestById(produits)
          .filter((p) => p.action !== 'supprimer'))),
        google: nettoyer(valides(latestById(google))),
      });
    } catch (e) {
      console.error(e.message);
      /* en cas de souci, la page garde son contenu d'origine */
      return jsonPublic({ theme: {}, textes: [], notices: [], produits: [], google: [] });
    }
  }

  if (url.pathname === '/api/theme') {
    try {
      const { subs } = await formSubmissions(THEME_FORM);
      const t = latestById(subs)
        .filter((x) => x.id === 'theme' && x.action !== 'supprimer')
        .filter((x) => itemSignatureValid(x, secret))
        .map(({ sig, id, _submissionId, _created, ...rest }) => rest)[0];
      return jsonPublic(t || {});
    } catch (e) { console.error(e.message); return jsonPublic({}); }
  }

  if (url.pathname === '/api/notices') {
    const pg = url.searchParams.get('page');
    try {
      const { subs } = await formSubmissions(NOTICE_FORM);
      const items = latestById(subs)
        .filter((x) => !pg || x.page === pg)
        .filter((x) => itemSignatureValid(x, secret))
        .map(({ sig, _submissionId, _created, ...rest }) => rest);
      return jsonPublic(items);
    } catch (e) { console.error(e.message); return jsonPublic([]); }
  }

  if (url.pathname === '/api/google') {
    try {
      const { subs } = await formSubmissions(GOOGLE_FORM);
      const items = latestById(subs)
        .filter((x) => itemSignatureValid(x, secret))
        .map(({ sig, _submissionId, _created, ...rest }) => rest);
      return jsonPublic(items);
    } catch (e) { console.error(e.message); return jsonPublic([]); }
  }

  if (url.pathname === '/api/textes') {
    /* filtré par page : chaque page ne reçoit que ses propres textes */
    const pg = url.searchParams.get('page');
    try {
      const { subs } = await formSubmissions(TEXTE_FORM);
      const items = latestById(subs)
        .filter((x) => x.action !== 'supprimer')
        .filter((x) => !pg || x.page === pg)
        .filter((x) => itemSignatureValid(x, secret))
        .map(({ sig, _submissionId, _created, ...rest }) => rest);
      return jsonPublic(items);
    } catch (e) { console.error(e.message); return jsonPublic([]); }
  }

  if (url.pathname === '/api/produits' || url.pathname === '/api/blog') {
    const formName = url.pathname === '/api/produits' ? PRODUCT_FORM : BLOG_FORM;
    try {
      const { subs } = await formSubmissions(formName);
      const items = latestById(subs)
        .filter((p) => p.action !== 'supprimer')
        .filter((p) => itemSignatureValid(p, secret))
        .map(({ sig, _submissionId, ...rest }) => rest);
      return jsonPublic(items);
    } catch (e) { console.error(e.message); return jsonPublic([]); }
  }

  /* ---- connexion : les identifiants Netlify servent de secours initial.
     Après modification depuis le back-office, les identifiants chiffrés dans
     Netlify Blobs deviennent prioritaires, sans exposer le mot de passe. ---- */
  const creds = await getEffectiveCredentials();
  if (!creds.username || (!creds.password && !creds.passwordRecord)) {
    return json({ error: "ADMIN_USER + ADMIN_PASSWORD doivent être configurés dans Netlify pour initialiser l'accès." }, 500);
  }

  if (path === '/login' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Requête invalide' }, 400); }
    const okUser = !!body.user && safeEqual(body.user, creds.username);
    const okPass = creds.overridden
      ? (!!body.password && verifyAdminPassword(body.password, creds.passwordRecord))
      : (!!body.password && safeEqual(body.password, creds.password));
    if (!okUser || !okPass) {
      /* petit délai : rend une attaque par essais successifs inexploitable,
         et le message reste volontairement identique dans les deux cas. */
      await new Promise((r) => setTimeout(r, 700));
      return json({ error: 'Identifiant ou mot de passe incorrect' }, 401);
    }
    const token = makeSessionToken(secret);
    return json({ ok: true }, 200, {
      'set-cookie': `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_HOURS * 3600}`,
    });
  }

  if (path === '/logout' && request.method === 'POST') {
    return json({ ok: true }, 200, {
      'set-cookie': `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`,
    });
  }

  /* Médias publics servis depuis Blobs. */
  if (url.pathname.startsWith('/api/media/') && request.method === 'GET') {
    const key = decodeURIComponent(url.pathname.slice('/api/media/'.length));
    if (!key.startsWith('uploads/')) return new Response('Not found', { status: 404 });
    try {
      const store = await blobStore(MEDIA_STORE);
      const meta = await store.getMetadata(key, { consistency: 'strong' });
      if (!meta) return new Response('Not found', { status: 404 });
      const data = await store.get(key, { type: 'arrayBuffer', consistency: 'strong' });
      return new Response(data, {
        headers: {
          'content-type': meta.metadata?.contentType || 'application/octet-stream',
          'cache-control': 'public, max-age=31536000, immutable',
          'content-disposition': 'inline',
        },
      });
    } catch (e) {
      console.error('Lecture média impossible :', e.message);
      return new Response('Not found', { status: 404 });
    }
  }

  const session = getCookie(request, COOKIE_NAME);
  const authed = verifySessionToken(session, secret);

  if (path === '/session') {
    return json({ authed });
  }

  if (!authed) {
    return json({ error: 'Connexion requise' }, 401);
  }

  /* ── Base clients persistante dans Netlify Blobs ───────────────── */
  if (path === '/clients' && request.method === 'GET') {
    try {
      const store = await blobStore(CLIENT_STORE);
      const data = await store.get('clients', { type: 'json', consistency: 'strong' });
      return json({ clients: Array.isArray(data) ? data : [] });
    } catch (e) { return json({ error: e.message }, 500); }
  }
  if (path === '/clients' && request.method === 'POST') {
    try {
      const body = await request.json();
      const incoming = Array.isArray(body?.clients) ? body.clients : [];
      const store = await blobStore(CLIENT_STORE);
      const current = await store.get('clients', { type: 'json', consistency: 'strong' });
      const merged = Array.isArray(current) ? current.slice() : [];
      for (const c of incoming) {
        if (!c || !c.fullName) continue;
        const i = merged.findIndex(x => String(x.id) === String(c.id) || String(x.fullName).toLowerCase() === String(c.fullName).toLowerCase());
        if (i >= 0) merged[i] = { ...merged[i], ...c };
        else merged.push(c);
      }
      await store.set('clients', JSON.stringify(merged));
      return json({ ok: true, clients: merged });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* ── Identifiants administrateur modifiables depuis le back-office ── */
  if (path === '/admin-settings' && request.method === 'GET') {
    try {
      const c = await getEffectiveCredentials();
      return json({ username: c.username });
    } catch (e) { return json({ error: e.message }, 500); }
  }
  if (path === '/admin-settings' && request.method === 'POST') {
    try {
      const body = await request.json();
      const newUser = String(body.username || '').trim();
      const newPassword = String(body.password || '');
      if (!newUser || newUser.length < 3) return json({ error: 'Identifiant invalide (3 caractères minimum).' }, 400);
      if (!newPassword || newPassword.length < 8) return json({ error: 'Mot de passe invalide (8 caractères minimum).' }, 400);
      const passwordRecord = hashAdminPassword(newPassword);
      const store = await blobStore(AUTH_STORE);
      await store.set('credentials', JSON.stringify({ username: newUser, passwordRecord, updatedAt: new Date().toISOString() }));
      return json({ ok: true, username: newUser, message: 'Identifiants administrateur enregistrés.' });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* Upload privé depuis le back-office. */
  if (path === '/fichier' && request.method === 'POST') {
    try {
      const form = await request.formData();
      const fichier = form.get('fichier');
      if (!(fichier instanceof File)) return json({ error: 'Fichier absent' }, 400);
      if (fichier.size > 20 * 1024 * 1024) return json({ error: 'Fichier trop volumineux (20 Mo maximum)' }, 400);
      const safeName = String(fichier.name || 'fichier').replace(/[^a-zA-Z0-9._-]+/g, '-').slice(-120);
      const key = `uploads/${Date.now().toString(36)}-${randomUUID()}-${safeName}`;
      const store = await blobStore(MEDIA_STORE);
      await store.set(key, fichier, {
        metadata: { contentType: fichier.type || 'application/octet-stream', filename: safeName },
      });
      return json({ pdf: `/api/media/${encodeURIComponent(key)}` });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* ── Migration unique Netlify Forms → Netlify Blobs ────────────────
     La migration lit les anciennes soumissions avant toute suppression.
     Elle est protégée par la session admin et peut être relancée sans
     écraser les données publiques : les clés restent stables. */
  if (path === '/migrate-blobs' && request.method === 'POST') {
    try {
      const map = {
        produits: PRODUCT_FORM, blog: BLOG_FORM, theme: THEME_FORM,
        textes: TEXTE_FORM, google: GOOGLE_FORM, notices: NOTICE_FORM,
        reservations: RESA_FORM, suivi: SUIVI_FORM, logistique: LOGISTIQUE_FORM,
      };
      const result = { collections: {}, avis: 0, avisDemandes: 0, fichiers: 0, erreurs: [] };
      const mediaMap = {};

      try {
        const { subs } = await netlifyFormSubmissions(FICHIER_FORM);
        const media = await blobStore(MEDIA_STORE);
        for (const sub of subs) {
          const d = sub.data || {};
          const f = typeof d.fichier === 'string' ? d.fichier : d.fichier?.url;
          if (!f) continue;
          try {
            const r = await fetch(f);
            if (!r.ok) continue;
            const buf = await r.arrayBuffer();
            const filename = (d.fichier?.name || f.split('/').pop() || 'fichier').replace(/[^a-zA-Z0-9._-]+/g, '-').slice(-120);
            const key = `uploads/migration-${sub.id}-${filename}`;
            await media.set(key, buf, {
              metadata: { contentType: r.headers.get('content-type') || 'application/octet-stream', filename },
            });
            mediaMap[f] = `/api/media/${encodeURIComponent(key)}`;
            if (d.ref) mediaMap[d.ref] = mediaMap[f];
            result.fichiers++;
          } catch (e) { result.erreurs.push(`fichier ${sub.id}: ${e.message}`); }
        }
      } catch (e) { result.erreurs.push(`fichiers-admin: ${e.message}`); }

      const replaceUrls = (value) => {
        if (typeof value === 'string') {
          let out = value;
          for (const [from, to] of Object.entries(mediaMap)) out = out.split(from).join(to);
          return out;
        }
        if (Array.isArray(value)) return value.map(replaceUrls);
        if (value && typeof value === 'object') {
          for (const k of Object.keys(value)) value[k] = replaceUrls(value[k]);
        }
        return value;
      };

      for (const [collection, formName] of Object.entries(map)) {
        try {
          const { subs } = await netlifyFormSubmissions(formName);
          const current = latestById(subs);
          let n = 0;
          for (const item of current) {
            const copy = replaceUrls(JSON.parse(JSON.stringify(item)));
            delete copy._submissionId;
            await saveBlobItem(collection, copy, secret);
            n++;
          }
          result.collections[collection] = n;
        } catch (e) { result.erreurs.push(`${collection}: ${e.message}`); }
      }

      try {
        const { subs } = await netlifyFormSubmissions(AVIS_FORM);
        for (const sub of subs) {
          const d = sub.data || {};
          if (d.p && d.t) { await savePublishedReview(d); result.avis++; }
        }
      } catch (e) { result.erreurs.push(`avis-valides: ${e.message}`); }

      /* Les avis clients encore en attente sont également conservés. */
      try {
        const { subs } = await netlifyFormSubmissions('avis-produit');
        const reviewStore = await blobStore(REVIEW_STORE);
        for (const sub of subs) {
          const d = sub.data || {};
          if (!d.produit || !d.avis) continue;
          const id = createHash('sha256').update(String(sub.id)).digest('hex').slice(0, 24);
          await reviewStore.set(`pending/migration-${id}`, JSON.stringify({
            id: `migration-${id}`,
            produit: d.produit,
            nom: d.nom || d.prenom || '',
            note: parseInt(d.note,10) || 5,
            avis: d.avis,
            email: d.email || '',
            _created: sub.created_at || new Date().toISOString(),
            status: 'pending',
          }));
          result.avisDemandes++;
        }
      } catch (e) { result.erreurs.push(`avis-produit: ${e.message}`); }

      const marker = await blobStore();
      await marker.set('_system/migration', JSON.stringify({ doneAt: new Date().toISOString(), result }));
      await viderCache();
      return json({ ok: true, ...result, message: 'Migration terminée. Vérifiez le back-office avant de supprimer les anciens formulaires Netlify.' });
    } catch (e) {
      return json({ error: e.message }, 500);
    }
  }

  /* Suppression finale des anciens Forms internes.
     On ne l'autorise que si un marqueur de migration existe et ne signale
     aucune erreur. Les trois formulaires publics devis / reservation /
     newsletter ne sont jamais touchés. */
  if (path === '/cleanup-netlify-forms' && request.method === 'POST') {
    try {
      const marker = await blobStore().get('_system/migration', { type: 'json', consistency: 'strong' });
      if (!marker?.result) {
        return json({ error: 'Migration initiale absente : lancez la migration avant de supprimer les anciens Forms.' }, 409);
      }
      const keep = new Set(['devis', 'reservation', 'newsletter']);
      const forms = await netlifyApi(`/sites/${await siteId()}/forms`);
      const internalNames = new Set([...INTERNAL_FORMS, 'avis-produit']);
      const deleted = [];
      for (const form of forms) {
        if (keep.has(form.name)) continue;
        if (!internalNames.has(form.name)) continue;
        try {
          await netlifyApi(`/sites/${await siteId()}/forms/${encodeURIComponent(form.id)}`, { method: 'DELETE' });
          deleted.push(form.name);
        } catch (e) {
          return json({ error: `Impossible de supprimer ${form.name}: ${e.message}`, deleted }, 500);
        }
      }
      return json({ ok: true, deleted, kept: [...keep] });
    } catch (e) {
      return json({ error: e.message }, 500);
    }
  }

  /* ---- CRUD produits / blog ---- */
  if (path === '/data' && request.method === 'GET') {
    const collection = url.searchParams.get('collection');
    const formName = formDe(collection);
    if (!formName) return json({ error: 'collection invalide' }, 400);
    try {
      const { subs } = await formSubmissions(formName);
      const courantes = latestById(subs);
      /* _valide indique si l'enregistrement s'affiche sur le site public :
         utile pour repérer un envoi non signé déposé par un tiers. */
      const items = courantes.map((it) => ({ ...it, _valide: itemSignatureValid(it, secret) }));
      /* les versions dépassées s'effacent au fil des consultations */
      try { await nettoyerVersionsPerimees(subs, courantes); } catch {}
      return json(items);
    } catch (e) { return json({ error: e.message }, 500); }
  }

  if (path === '/data' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Requête invalide' }, 400); }
    const { collection, item } = body;
    const formName = formDe(collection);
    if (!formName || !item || !item.id) return json({ error: 'collection ou item invalide' }, 400);
    try {
      await submitToForm(formName, item, secret);
      const cache = await viderCache();
      return json({ ok: true, cache });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  if (path === '/data' && request.method === 'DELETE') {
    const collection = url.searchParams.get('collection');
    const id = url.searchParams.get('id');
    const formName = formDe(collection);
    if (!formName || !id) return json({ error: 'collection ou id invalide' }, 400);
    try {
      const n = await deleteAllSubmissionsWithId(formName, id);
      const cache = await viderCache();
      return json({ ok: true, deleted: n, cache });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* ---- demandes de devis venues du site ----------------------------
     Les demandes arrivent dans le formulaire public « reservation » :
     elles ne sont jamais modifiées ici. Leur suivi (nouvelle, en cours,
     validée) est enregistré à part, dans « suivi-demandes-admin », et
     rapproché de la demande par l'identifiant que Netlify lui a donné.
     Une demande sans suivi est donc « nouvelle » par défaut.
     ------------------------------------------------------------------ */
  if (path === '/demandes' && request.method === 'GET') {
    try {
      const [{ subs }, suivis] = await Promise.all([
        formSubmissions(DEMANDE_FORM),
        formSubmissions(SUIVI_FORM).then(({ subs }) => latestById(subs)),
      ]);
      const parId = new Map(suivis.map((x) => [x.id, x]));
      /* Une demande envoyée par un client n'est jamais réécrite : ce qu'il
         a saisi reste tel quel chez Netlify. Les corrections faites depuis
         le back-office sont enregistrées à côté et appliquées par-dessus à
         la lecture — on peut donc toujours revenir à l'original. */
      const corrige = (suivi, champ, valeur) =>
        suivi['c_' + champ] !== undefined && suivi['c_' + champ] !== '' ? suivi['c_' + champ] : valeur;

      const items = subs.map((sub) => {
        const d = sub.data || {};
        const suivi = parId.get(sub.id) || {};
        return {
          id: sub.id,
          recue: sub.created_at,
          statut: suivi.statut || 'nouvelle',
          resaId: suivi.resaId || '',
          /* photobooth uniquement : où en est la création du cadre */
          cadre: suivi.cadre || '',
          note: suivi.note || '',
          nom: corrige(suivi, 'nom', [d.prenom, d.nom].filter(Boolean).join(' ') || d.nom || d.name || ''),
          email: corrige(suivi, 'email', d.email || ''),
          telephone: corrige(suivi, 'telephone', d.telephone || d.tel || ''),
          date: corrige(suivi, 'date', d.date || ''),
          convives: corrige(suivi, 'convives', d.convives || ''),
          type: corrige(suivi, 'type', d.type || ''),
          demande: d.demande || '',
          livraison: corrige(suivi, 'livraison', d.livraison || ''),
          adresse: corrige(suivi, 'adresse', d.adresse_livraison || ''),
          message: corrige(suivi, 'message', d.message || ''),
          panier: d.cartData || '',
          materiel: suivi.c_materiel || '',
          categories: d.catsData || '',
          origine: d.origine || d.connu || '',
        };
      }).sort((a, b) => new Date(b.recue) - new Date(a.recue));
      return json(items);
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* changement de statut : on n'écrit que le suivi, jamais la demande */
  if (path === '/demandes' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Requête invalide' }, 400); }
    const statuts = ['nouvelle', 'en-cours', 'validee'];
    const cadres = ['', 'a-creer', 'en-cours', 'termine'];
    if (!body.id || !statuts.includes(body.statut)) return json({ error: 'demande ou statut invalide' }, 400);
    if (body.cadre !== undefined && !cadres.includes(body.cadre)) return json({ error: 'avancement du cadre invalide' }, 400);
    try {
      const champs = {
        id: String(body.id),
        statut: body.statut,
        resaId: body.resaId ? String(body.resaId) : '',
        cadre: body.cadre || '',
        note: body.note ? String(body.note).slice(0, 600) : '',
      };
      /* corrections apportées depuis le back-office, préfixées c_ pour ne
         jamais se confondre avec les champs de suivi */
      const CORRIGEABLES = ['nom', 'telephone', 'email', 'date', 'convives',
                            'type', 'livraison', 'adresse', 'message', 'materiel'];
      if (body.corrections && typeof body.corrections === 'object') {
        for (const champ of CORRIGEABLES) {
          const v = body.corrections[champ];
          if (v !== undefined && v !== null) champs['c_' + champ] = String(v).slice(0, 1200);
        }
      }
      await submitToForm(SUIVI_FORM, champs, secret);
      return json({ ok: true });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* suppression d'une demande : la demande d'origine et son suivi */
  if (path === '/demandes' && request.method === 'DELETE') {
    const id = url.searchParams.get('id');
    if (!id) return json({ error: 'identifiant absent' }, 400);
    try {
      await netlifyApi(`/submissions/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await deleteAllSubmissionsWithId(SUIVI_FORM, String(id));
      return json({ ok: true });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* ---- fichiers admin : upload direct vers Netlify Blobs ----------- */
  if (path === '/fichier' && request.method === 'POST') {
    try {
      const form = await request.formData();
      const fichier = form.get('fichier');
      if (!(fichier instanceof File)) return json({ error: 'Fichier absent' }, 400);
      if (fichier.size > 20 * 1024 * 1024) return json({ error: 'Fichier trop volumineux (20 Mo maximum)' }, 400);
      const safeName = String(fichier.name || 'fichier').replace(/[^a-zA-Z0-9._-]+/g, '-').slice(-120);
      const key = `uploads/${Date.now().toString(36)}-${randomUUID()}-${safeName}`;
      const store = await blobStore(MEDIA_STORE);
      await store.set(key, fichier, {
        metadata: { contentType: fichier.type || 'application/octet-stream', filename: safeName },
      });
      return json({ pdf: `/api/media/${encodeURIComponent(key)}` });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  /* ---- publication directe d'un avis (admin = pas besoin du lien e-mail) ---- */
  if (path === '/avis' && request.method === 'POST') {
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Requête invalide' }, 400); }
    const mois = new Date().toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
    const d = mois.charAt(0).toUpperCase() + mois.slice(1);
    try {
      await submitToForm(AVIS_FORM, {
        p: (body.produit || '').slice(0, 200),
        n: (body.nom || '').slice(0, 200),
        s: String(Math.max(1, Math.min(5, parseInt(body.note, 10) || 5))),
        t: (body.texte || '').slice(0, 900),
        d,
      });
      await viderCache();
      return json({ ok: true });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  if (path === '/data-delete-avis' && request.method === 'POST') {
    // suppression d'un avis publié (par contenu, les avis n'ont pas d'id)
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Requête invalide' }, 400); }
    try {
      const ok = await deletePublishedReview(body.nom, body.texte);
      if (!ok) return json({ error: 'Avis introuvable' }, 404);
      await viderCache();
      return json({ ok: true });
    } catch (e) { return json({ error: e.message }, 500); }
  }

  return json({ error: 'Route inconnue' }, 404);
};
