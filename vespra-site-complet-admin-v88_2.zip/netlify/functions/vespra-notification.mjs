/* ============================================================
   Vespra Event — notification e-mail sur soumission de formulaire
   Déclenchée par Netlify à chaque envoi de formulaire vérifié.
   Envoie un e-mail mis en forme via l'API Resend.

   Variables d'environnement à définir dans Netlify :
     RESEND_API_KEY   clé API Resend (commence par re_)
     NOTIFY_TO        adresse qui reçoit les notifications
     NOTIFY_FROM      expéditeur, ex. "Vespra Event <devis@vespraevent.fr>"
   ============================================================ */

const NAVY = '#2B4A6B', GOLD = '#F59E0B', DARK = '#0C0F14';
const G1 = '#3D4452', G2 = '#646D7C', G3 = '#C8CDD8', G4 = '#F0F2F5';

/* Met en forme les dates ISO (2026-07-18) en français */
const frDate = v => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v ?? '').trim());
  if (!m) return v;
  const d = new Date(`${m[1]}-${m[2]}-${m[3]}T12:00:00`);
  return isNaN(d) ? v : d.toLocaleDateString('fr-FR', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
};

const esc = v => String(v ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

/* Libellés lisibles pour les noms de champs techniques */
const LABELS = {
  demande: 'Nature de la demande',
  nom: 'Nom', prenom: 'Prénom', email: 'E-mail', telephone: 'Téléphone',
  tel: 'Téléphone', type: "Type d'événement", 'type-evenement': "Type d'événement",
  date: 'Date de l’événement', convives: 'Nombre de convives',
  livraison: 'Livraison', adresse_livraison: 'Adresse de livraison',
  message: 'Message', produit: 'Produit', note: 'Note', avis: 'Avis',
  livraison_installation: 'Livraison et installation', adresse_livraison: 'Adresse de livraison',
};

/* Champs à ne jamais afficher tels quels */
const HIDDEN = new Set(['form-name', 'subject', 'bot-field', 'cartData', 'catsData',
  'ip', 'user_agent', 'referrer', 'user-agent', 'from', 'title', 'created_at', 'site_url']);

const row = (label, value, mono) => `
  <tr>
    <td style="padding:11px 0;border-bottom:1px solid ${G4};color:${G2};font-size:13px;width:38%;vertical-align:top">${esc(label)}</td>
    <td style="padding:11px 0;border-bottom:1px solid ${G4};color:${DARK};font-size:14px;font-weight:600${mono ? ';font-family:monospace' : ''}">${value}</td>
  </tr>`;

/* Tableau des produits demandés : panier + sélection par catégories */
const parseList = raw => {
  try { const v = JSON.parse(raw); return Array.isArray(v) ? v : []; } catch { return []; }
};
function cartTable(...raws) {
  const seen = new Set();
  const items = raws.flatMap(parseList).filter(it => {
    const k = [it.produit || it.name || '', it.formule || '', it.options || ''].join('|');
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
  if (!items.length) return `
  <h2 style="margin:32px 0 12px;font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:${NAVY}">Produits demandés</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:#fff;border:1px dashed ${G3};border-radius:8px">
    <tr><td style="padding:16px 14px;font-size:14px;color:${G1}">Aucun produit sélectionné sur le site — le client décrit son besoin dans son message ou attend votre conseil.</td></tr>
  </table>`;
  let total = 0, devis = false;
  const lines = items.map(it => {
    const p = Number(String(it.prix ?? it.price ?? '').replace(/[^\d.]/g, '')) || 0;
    if (/devis/i.test(String(it.prix ?? ''))) devis = true; else total += p;
    const det = [];
    if (it.formule) det.push(`<span style="color:${G2}">Formule&nbsp;:</span> ${esc(it.formule)}`);
    if (it.options) det.push(`<span style="color:${G2}">Options&nbsp;:</span> ${esc(it.options)}`);
    const opts = det.length
      ? `<div style="margin-top:4px;font-size:12.5px;font-weight:400;color:${G1};line-height:1.6">${det.join('<br>')}</div>`
      : '';
    return `<tr>
      <td style="padding:12px;border-bottom:1px solid ${G4};font-size:14px;color:${DARK};font-weight:600">${esc(it.produit || it.name || '')}${opts}</td>
      <td style="padding:10px 12px;border-bottom:1px solid ${G4};font-size:14px;color:${NAVY};font-weight:700;text-align:right;white-space:nowrap">${esc(it.prix ?? (p + ' €'))}</td>
    </tr>`;
  }).join('');
  return `
  <h2 style="margin:32px 0 12px;font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:${NAVY}">Produits demandés</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:#fff;border:1px solid ${G4};border-radius:8px;overflow:hidden">
    ${lines}
    <tr>
      <td style="padding:14px 12px;font-size:14px;font-weight:700;color:${DARK};background:${G4}">Total estimé</td>
      <td style="padding:14px 12px;font-size:16px;font-weight:700;color:${NAVY};text-align:right;background:${G4};white-space:nowrap">${total} €${devis ? ' + sur devis' : ''}</td>
    </tr>
  </table>`;
}

function buildHtml(kind, data) {
  const nom = [data.prenom, data.nom].filter(Boolean).join(' ') || 'Client';
  const mail = data.email || '';
  const tel = data.telephone || data.tel || '';

  const contact = `
  <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:${G4};border-radius:10px;margin:0 0 8px">
    <tr><td style="padding:20px 22px">
      <div style="font-size:19px;font-weight:700;color:${DARK};margin-bottom:10px">${esc(nom)}</div>
      ${mail ? `<div style="margin-bottom:5px"><a href="mailto:${esc(mail)}" style="color:${NAVY};font-size:15px;text-decoration:none;font-weight:600">${esc(mail)}</a></div>` : ''}
      ${tel ? `<div><a href="tel:${esc(tel.replace(/\s/g, ''))}" style="color:${NAVY};font-size:15px;text-decoration:none;font-weight:600">${esc(tel)}</a></div>` : ''}
    </td></tr>
  </table>`;

  const details = Object.entries(data)
    .filter(([k, v]) => !HIDDEN.has(k) && v && !['nom','prenom','email','telephone','tel','message','avis'].includes(k))
    .map(([k, v]) => {
      if (k === 'note') {
        const n = Math.max(0, Math.min(5, parseInt(v, 10) || 0));
        return row('Note', `<span style="color:${GOLD};font-size:17px;letter-spacing:2px">${'★'.repeat(n)}<span style="color:#d4d8e0">${'★'.repeat(5 - n)}</span></span> <span style="color:${G2};font-size:13px;font-weight:400">${n}/5</span>`);
      }
      return row(LABELS[k] || k, esc(/date/i.test(k) ? frDate(v) : v));
    })
    .join('');

  const msg = data.message || data.avis;
  const msgBlock = msg ? `
  <h2 style="margin:32px 0 12px;font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:${NAVY}">Message</h2>
  <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:#fff;border-left:3px solid ${GOLD};border-radius:0 8px 8px 0">
    <tr><td style="padding:16px 20px;font-size:15px;line-height:1.7;color:${G1};white-space:pre-wrap">${esc(msg)}</td></tr>
  </table>` : '';

  return `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(kind.title)}</title></head>
<body style="margin:0;padding:0;background:#eef0f4;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:#eef0f4">
  <tr><td align="center" style="padding:28px 14px">
    <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;max-width:600px;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.07)">

      <tr><td style="background:${NAVY};padding:26px 30px">
        <div style="font-size:22px;font-weight:800;letter-spacing:.16em;color:#fff">VESPRA EVENT</div>
        <div style="font-size:12px;color:rgba(255,255,255,.62);margin-top:3px">Location de matériel événementiel — Vitré</div>
      </td></tr>

      <tr><td style="padding:26px 30px 0">
        <div style="display:inline-block;background:${kind.bg};color:${kind.fg};font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;padding:6px 13px;border-radius:999px">${esc(kind.badge)}</div>
        <h1 style="margin:16px 0 22px;font-size:23px;line-height:1.3;color:${DARK};font-weight:700">${esc(kind.title)}</h1>
        ${contact}
        ${details ? `<h2 style="margin:30px 0 4px;font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:${NAVY}">Détails</h2>
        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">${details}</table>` : ''}
        ${kind.review ? '' : cartTable(data.cartData, data.catsData)}
        ${msgBlock}
      </td></tr>

      <tr><td style="padding:30px">
        ${kind.review
          ? (kind.link
              ? `<a href="${kind.link}" style="display:block;background:#15803d;color:#fff;text-align:center;padding:16px;border-radius:999px;font-size:16px;font-weight:700;text-decoration:none">Publier cet avis sur le site</a>
                 <div style="margin-top:14px;text-align:center;font-size:13.5px;line-height:1.7;color:${G2}">
                   Un seul clic suffit, l'avis apparaît sur la fiche produit dans la minute.<br>
                   <strong style="color:${G1}">Si l'avis ne vous convient pas, ne cliquez pas :</strong> rien ne sera publié.
                 </div>`
              : `<div style="background:#f0f7f2;border-left:3px solid #15803d;border-radius:0 8px 8px 0;padding:16px 20px;font-size:14px;line-height:1.7;color:${G1}">
                   <strong style="color:${DARK}">Publication en un clic non configurée</strong><br>
                   Ajoutez les variables <strong>NETLIFY_ACCESS_TOKEN</strong> et <strong>AVIS_SECRET</strong> dans Netlify pour obtenir un bouton ici. En attendant, collez la ligne ci-dessous dans le fichier <strong>avis.js</strong> du site.
                 </div>
                 <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-top:12px;background:#0C0F14;border-radius:8px">
                   <tr><td style="padding:16px 18px;font-family:Menlo,Consolas,'Courier New',monospace;font-size:13px;line-height:1.6;color:#e6e9ef;word-break:break-word">${esc(reviewLine(data))}</td></tr>
                 </table>`)
          : (mail ? `<a href="mailto:${esc(mail)}?subject=${encodeURIComponent('Votre demande — Vespra Event')}" style="display:block;background:${NAVY};color:#fff;text-align:center;padding:15px;border-radius:999px;font-size:15px;font-weight:700;text-decoration:none">Répondre au client</a>` : '')}
      </td></tr>

      <tr><td style="background:${DARK};padding:20px 30px;text-align:center">
        <div style="font-size:12px;color:rgba(255,255,255,.4)">Reçu via vespraevent.fr — ${new Date().toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</div>
      </td></tr>

    </table>
  </td></tr>
</table>
</body></html>`;
}

import { validationLink } from './avis.mjs';

/* Repli : ligne à coller si la validation en un clic n'est pas configurée */
function reviewLine(data) {
  const q = v => (v || '').toString().replace(/\\/g, '').replace(/"/g, "'").replace(/\s+/g, ' ').trim();
  const mois = new Date().toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  const note = Math.max(1, Math.min(5, parseInt(data.note, 10) || 5));
  return `{p:"${q(data.produit)}", n:"${q(data.nom || data.prenom)}", s:${note}, t:"${q(data.avis || data.message)}", d:"${mois.charAt(0).toUpperCase() + mois.slice(1)}"},`;
}

const KINDS = {
  devis:       { badge: 'Demande de devis', title: 'Nouvelle demande de devis', bg: 'rgba(43,74,107,.1)',  fg: NAVY },
  reservation: { badge: 'Réservation',      title: 'Nouvelle réservation à traiter', bg: 'rgba(245,158,11,.15)', fg: '#92400e' },
  'avis-produit': { badge: 'Avis client',   title: 'Nouvel avis client à valider', bg: 'rgba(34,197,94,.12)', fg: '#15803d', review: true },
  newsletter:  { badge: 'Newsletter',       title: 'Nouvelle inscription à la newsletter', bg: 'rgba(43,74,107,.1)', fg: NAVY },
  disponibilite: { badge: 'Disponibilité',  title: 'Demande de disponibilité', bg: 'rgba(245,158,11,.15)', fg: '#92400e' },
};

/* Netlify ne transmet pas toujours le champ form-name : on déduit alors
   le type de formulaire à partir des données elles-mêmes. */
function detectForm(formName, data) {
  // un avis se reconnaît à ses champs, quel que soit ce que Netlify transmet
  if (data.note || data.avis || /avis/i.test(data.subject || '')) return 'avis-produit';
  if (formName && KINDS[formName]) return formName;
  if (data.email && !data.message && !data.demande && Object.keys(data).length <= 3) return 'newsletter';
  if (data.demande || data.cartData) return 'reservation';
  return formName || 'devis';
}

async function notify(formName, data) {
  const key = process.env.RESEND_API_KEY;
  if (!key) { console.error('RESEND_API_KEY absente — e-mail non envoyé'); return; }
  const detected = detectForm(formName, data);
  console.log('Formulaire reçu :', formName || '(absent)', '→ traité comme', detected, '| champs :', Object.keys(data).join(','));
  formName = detected;
  let kind = KINDS[formName] || { badge: formName, title: 'Nouveau message', bg: 'rgba(43,74,107,.1)', fg: NAVY };
  // le formulaire de réservation sert deux intentions : on distingue la pastille
  if (formName === 'reservation' && /^Disponibilit/i.test(data.demande || '')) kind = KINDS.disponibilite;
  else if (formName === 'reservation' && data.demande) kind = KINDS.devis;
  if (formName === 'avis-produit') {
    if (data.produit) kind = { ...kind, title: `Nouvel avis à valider — ${data.produit}` };
    const secret = process.env.AVIS_SECRET;
    if (secret && process.env.NETLIFY_ACCESS_TOKEN) {
      try {
        kind = { ...kind, link: validationLink(data, { siteUrl: process.env.URL || 'https://www.vespraevent.fr', secret }) };
      } catch (e) { console.error('Lien de validation non généré :', e.message); }
    }
  }
  const body = {
    from: process.env.NOTIFY_FROM || 'Vespra Event <onboarding@resend.dev>',
    to: (process.env.NOTIFY_TO || 'vespraevent@gmail.com').split(',').map(s => s.trim()),
    subject: data.subject || kind.title,
    html: buildHtml(kind, data),
  };
  if (data.email) body.reply_to = data.email;

  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) console.error('Resend a refusé l’envoi :', r.status, await r.text());
  else console.log('Notification envoyée pour le formulaire', formName);
}

/* Syntaxe moderne : Netlify appelle formSubmitted à chaque soumission vérifiée */
export default {
  async formSubmitted(event) {
    const data = event.data || {};
    const name = data['form-name'] || event.form?.name || '';
    // « avis-valides » n'est pas un message de client : c'est le stockage
    // interne des avis publiés. Aucune notification pour celui-là.
    if (name === 'avis-valides' || (data.p && data.t && data.s && !data.avis && !data.message)) {
      console.log('Enregistrement interne d’un avis publié — pas de notification');
      return;
    }
    await notify(name, data);
  },
};
