/* ─────────────────────────────────────────────────────────────
   Un seul appel pour toute la page.

   Le site récupère, à chaque affichage, ce que le back-office a pu
   modifier : l'apparence, les textes réécrits, les notices, les prix et
   les avis Google. Cela faisait jusqu'à cinq allers-retours par page —
   cinq attentes pour le visiteur et cinq requêtes facturées.

   Ce fichier n'en fait plus qu'un, et distribue le résultat aux scripts
   qui en ont besoin. Chacun demande sa part par window.VESPRA_DONNEES,
   sans savoir si l'appel a déjà eu lieu : il n'est fait qu'une fois.

   Si l'appel échoue, chaque script reçoit une réponse vide et la page
   garde le contenu écrit dans ses fichiers : rien ne disparaît.
   ───────────────────────────────────────────────────────────── */
(function () {
  var VIDE = { theme: {}, textes: [], notices: [], produits: [], google: [] };

  /* l'aperçu d'apparence du back-office ne doit rien charger */
  if (/[?&]apercu=1/.test(location.search)) {
    window.VESPRA_DONNEES = function () { return Promise.resolve(VIDE); };
    return;
  }

  var page = (location.pathname.split('/').pop() || 'index.html');
  if (page.indexOf('.') === -1) page += '.html';

  var promesse = null;

  function charger() {
    if (promesse) return promesse;
    promesse = fetch('/api/site?page=' + encodeURIComponent(page), {
      headers: { accept: 'application/json' },
    })
      .then(function (r) { return r.ok ? r.json() : VIDE; })
      .then(function (d) {
        /* on complète ce qui manquerait, pour que les scripts n'aient
           jamais à vérifier la forme de ce qu'ils reçoivent */
        return {
          theme: (d && d.theme) || {},
          textes: (d && d.textes) || [],
          notices: (d && d.notices) || [],
          produits: (d && d.produits) || [],
          google: (d && d.google) || [],
        };
      })
      .catch(function () { return VIDE; });
    return promesse;
  }

  /* VESPRA_DONNEES('textes') rend directement la part demandée */
  window.VESPRA_DONNEES = function (quoi) {
    return charger().then(function (d) { return quoi ? d[quoi] : d; });
  };

  /* l'appel part tout de suite : les scripts qui suivent n'attendent pas */
  charger();
})();
