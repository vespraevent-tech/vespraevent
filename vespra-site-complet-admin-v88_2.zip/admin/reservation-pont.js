/* ─────────────────────────────────────────────────────────────
   Pont entre la page Réservation et le back-office.

   La page de gestion des réservations a été conçue pour fonctionner
   seule : elle enregistre tout dans le navigateur et possède sa propre
   connexion. Intégrée au back-office, deux choses changent :

   1. Les réservations et leur configuration sont enregistrées sur le
      serveur Netlify, comme le reste du back-office. Le planning est
      donc le même depuis le téléphone et depuis l'ordinateur, et il
      survit à un vidage du navigateur.

   2. La connexion du back-office suffit : la page ne redemande pas
      d'identifiants quand elle est ouverte à l'intérieur.

   Le code de la page n'est pas modifié : ce fichier remplace seulement
   les quatre fonctions de synchronisation qu'elle prévoyait déjà pour
   Firebase, et les redirige vers l'API du back-office.

   Ouverte seule (hors du back-office), la page retrouve son
   fonctionnement d'origine.
   ───────────────────────────────────────────────────────────── */
(function () {
  var DANS_LE_BO = window.parent !== window;

  /* Ouverte directement, hors du back-office, cette page présenterait son
     ancien écran de connexion — trompeur, puisque les données sont
     protégées par celle du back-office et qu'elle n'afficherait rien.
     On renvoie donc simplement vers le back-office. */
  if (!DANS_LE_BO) {
    location.replace('/admin/');
    return;
  }

  function api(chemin, options) {
    return fetch('/api/admin' + chemin, Object.assign({
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
    }, options || {})).then(function (r) {
      if (r.status === 401) { throw new Error('session'); }
      return r.json();
    });
  }

  /* ── enregistrement d'une réservation ───────────────────── */
  function enregistrer(r) {
    if (!r || !r.id) return Promise.resolve();
    return api('/data', {
      method: 'POST',
      body: JSON.stringify({ collection: 'reservations', item: { id: String(r.id), d: JSON.stringify(r) } }),
    });
  }

  function supprimer(id) {
    return api('/data?collection=reservations&id=' + encodeURIComponent(id), { method: 'DELETE' });
  }

  /* ── configuration (produits, tarifs, clients, achats, couleurs…) ──
     Elle est enregistrée en un seul bloc, comme le faisait déjà la page
     pour Firebase : c'est le même contenu, au même endroit. */
  var CLES = {
    prods: 'vespraProds', cats: 'vespraCats', src: 'vespraSrc', frais: 'vespraFrais',
    fraisCats: 'vespraFraisCats', colors: 'vespraColors', clients: 'vespraClients',
    purchases: 'vespraPurchases', equipGroups: 'vespraEquipGroups',
  };

  function configLocale() {
    var cfg = {};
    for (var k in CLES) {
      try { cfg[k] = JSON.parse(localStorage.getItem(CLES[k]) || 'null'); } catch (e) { cfg[k] = null; }
    }
    return cfg;
  }

  var enAttente = null;
  function enregistrerConfig() {
    /* plusieurs réglages changent souvent d'affilée : on n'envoie
       qu'une fois, une seconde après le dernier changement */
    clearTimeout(enAttente);
    enAttente = setTimeout(function () {
      api('/data', {
        method: 'POST',
        body: JSON.stringify({ collection: 'reservations', item: { id: 'cfg', d: JSON.stringify(configLocale()) } }),
      }).then(function () { badge('ok'); }).catch(function () { badge('err'); });
    }, 1000);
  }

  function badge(etat) {
    if (typeof window.updateSyncBadge === 'function') window.updateSyncBadge(etat);
    /* le back-office affiche cet état sur sa LED, en bas à gauche */
    if (window.parent !== window) {
      try { window.parent.postMessage({ type: 'vespra-sync', etat: etat }, location.origin); } catch (e) {}
    }
  }

  /* ── remplacement des fonctions de synchronisation ───────── */
  function brancher() {
    /* une adresse non vide suffit à réactiver les appels de synchronisation
       déjà écrits dans la page ; ils passent maintenant par les fonctions
       ci-dessous, et plus par Firebase */
    window.FIREBASE_URL = '/api/admin';

    window.fbPutRes = function (r) {
      badge('sync');
      enregistrer(r).then(function () { badge('ok'); }).catch(function () { badge('err'); });
    };
    window.fbDeleteRes = function (id) { supprimer(id).catch(function () { badge('err'); }); };
    window.fbPutCfg = function () { badge('sync'); enregistrerConfig(); };
    window.pushToFirebase = function (cb) { window.fbPutCfg(); if (cb) cb(true); };
    /* la page vérifiait la présence d'une base Firebase : inutile ici */
    window.startSSE = function () {};
    window.stopSSE = function () {};
  }

  /* ── tout changement enregistré dans le navigateur part au serveur ──
     La page enregistre ses données dans le navigateur, et ne prévoyait
     de les envoyer ailleurs qu'au moment d'un « envoi » manuel. On
     surveille donc ses écritures : dès qu'une réservation ou un réglage
     change, la modification part au serveur toute seule. */
  var connuR = {};

  function pousserReservations() {
    var liste = [];
    try { liste = JSON.parse(localStorage.getItem('vespraR') || '[]'); } catch (e) { return; }
    var vus = {};
    liste.forEach(function (r) {
      if (!r || !r.id) return;
      var brut = JSON.stringify(r);
      vus[r.id] = true;
      if (connuR[r.id] !== brut) { connuR[r.id] = brut; enregistrer(r).catch(function () { badge('err'); }); }
    });
    /* une réservation qui a disparu de la liste a été supprimée */
    Object.keys(connuR).forEach(function (id) {
      if (!vus[id]) { delete connuR[id]; supprimer(id).catch(function () {}); }
    });
  }

  var attenteR = null;
  function surveiller() {
    var brut = Storage.prototype.setItem;
    var clesCfg = Object.keys(CLES).map(function (k) { return CLES[k]; });
    Storage.prototype.setItem = function (cle, valeur) {
      brut.call(this, cle, valeur);
      if (this !== window.localStorage) return;
      if (cle === 'vespraR') {
        clearTimeout(attenteR);
        attenteR = setTimeout(pousserReservations, 400);
      } else if (clesCfg.indexOf(cle) !== -1) {
        enregistrerConfig();
      }
    };
  }

  /* ── premier chargement : on lit ce qui est sur le serveur ── */
  function charger() {
    badge('sync');
    return api('/data?collection=reservations').then(function (items) {
      if (!Array.isArray(items)) return;
      var resas = [];
      var cfg = null;
      items.forEach(function (it) {
        if (!it || !it.d) return;
        var v;
        try { v = JSON.parse(it.d); } catch (e) { return; }
        if (it.id === 'cfg') cfg = v; else resas.push(v);
      });

      if (cfg && typeof window.applyConfig === 'function') window.applyConfig(cfg);

      /* le planning ne part de zéro que si le serveur a déjà quelque chose :
         une première ouverture ne doit pas effacer ce qui est dans le
         navigateur, elle doit au contraire le transmettre au serveur */
      if (resas.length) {
        window.R = resas;
        try { localStorage.setItem('vespraR', JSON.stringify(resas)); } catch (e) {}
      } else {
        var local = [];
        try { local = JSON.parse(localStorage.getItem('vespraR') || '[]'); } catch (e) {}
        local.forEach(enregistrer);
        if (local.length) enregistrerConfig();
      }
      /* on note l'état de départ : seules les modifications suivantes
         seront renvoyées au serveur */
      try {
        JSON.parse(localStorage.getItem('vespraR') || '[]').forEach(function (r) {
          if (r && r.id) connuR[r.id] = JSON.stringify(r);
        });
      } catch (e) {}

      badge('ok');
    }).catch(function () { badge('err'); });
  }

  /* ── fondu dans le back-office ───────────────────────────────
     Intégré, l'outil n'a plus besoin de son propre bandeau bleu ni de
     son menu de gauche : le titre, la déconnexion et la navigation sont
     déjà ceux du back-office, et les afficher deux fois est déroutant.
     Seul le contenu de la page reste, calé sur toute la largeur du
     cadre. L'indicateur de synchronisation est conservé, discrètement,
     car il dit si les modifications sont bien parties sur le serveur.

     Rien n'est supprimé de la page : tout est masqué par une feuille de
     style. Ouverte seule, la page reste complète. */
  function fondre() {
    var st = document.createElement('style');
    st.textContent = [
      'header{display:none!important}',
      '.layout{height:100vh!important}',
      'aside{display:none!important}',
      'main{overflow:auto!important}',
      '.page{padding:20px 22px 40px!important;max-width:none!important}',
      'body{background:#fff!important}',
      /* l\'état de synchronisation est repris par la LED du back-office,
         en bas à gauche : l\'afficher deux fois n\'apporte rien */
      '#sync-badge{display:none!important}',
      '@media(max-width:860px){.page{padding:16px 14px 34px!important}}',
    ].join('');
    document.head.appendChild(st);


  }

  /* ── ouverture d'une page depuis le menu du back-office ──── */
  window.addEventListener('message', function (e) {
    if (e.source !== window.parent) return;
    var m = e.data;
    if (!m) return;
    if (m.type === 'vespra-page' && m.page) {
      window.page = m.page;
      if (typeof window.nav === 'function') window.nav();
      return;
    }
    /* la flèche d'actualisation du back-office : on redemande au serveur */
    if (m.type === 'vespra-recharger') {
      charger().then(function () { if (typeof window.nav === 'function') window.nav(); });
      return;
    }
    /* le back-office demande d'ouvrir une réservation précise */
    if (m.type === 'vespra-ouvrir' && m.id) {
      window.page = 'planning';
      if (typeof window.nav === 'function') window.nav();
      if (typeof window.openDetail === 'function') window.openDetail(m.id);
    }
  });

  function demarrer() {
    brancher();
    surveiller();

    if (DANS_LE_BO) {
      fondre();
      /* la connexion du back-office fait foi */
      if (typeof window.hideAuthScreens === 'function') window.hideAuthScreens();
      var o = document.getElementById('auth-overlay');
      if (o) o.style.display = 'none';
      if (!window.currentUser) {
        window.currentUser = { firstName: 'Vespra', lastName: 'Event', email: '', role: 'admin' };
        if (typeof window.updateHeaderUser === 'function') window.updateHeaderUser();
      }
    }

    charger().then(function () {
      if (typeof window.nav === 'function') window.nav();
      /* le back-office peut avoir demandé une page précise dès l'ouverture */
      var p = new URLSearchParams(location.search).get('page');
      if (p) { window.page = p; if (typeof window.nav === 'function') window.nav(); }
      if (window.parent !== window) window.parent.postMessage({ type: 'vespra-prete' }, location.origin);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})();
