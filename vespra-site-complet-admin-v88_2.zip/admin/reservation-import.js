/* ─────────────────────────────────────────────────────────────
   Reprise du planning tenu sous Excel.

   Les réservations de 2026, 2027 et 2028 étaient jusqu'ici notées dans
   un classeur. Elles sont reprises ici telles quelles : même client,
   même date, même matériel, même montant, même lieu de livraison.

   La reprise se fait toute seule à la première ouverture du back-office :
   il n'y a rien à cliquer. Elle n'a lieu qu'une fois, et chaque
   réservation reprise porte un identifiant tiré de son nom et de sa date,
   si bien qu'une ligne déjà présente n'est jamais ajoutée deux fois — et
   qu'une réservation supprimée à la main ne revient pas. Les réservations
   saisies dans le back-office ne sont jamais touchées. Si la reprise
   échoue (serveur injoignable), un bandeau propose de réessayer.

   Deux locations manquaient au catalogue du planning : le vidéoprojecteur
   (ajouté à la sonorisation, comme sur le site) et le livre d'or audio
   (dans une nouvelle catégorie « Animation »). La shampouineuse, retirée
   du catalogue, n'est pas reprise.

   La feuille « Tarifs » du classeur n'est pas reprise : elle ne
   contient pas de réservations.
   ───────────────────────────────────────────────────────────── */
(function () {
  var FICHIER = 'reservations-historique.json';
  var PREFIXE = 'xls-';

  /* Le vidéoprojecteur rejoint la sonorisation, comme sur le site
     (catégorie « Son et vidéo »). Le livre d'or audio est une animation :
     le planning n'avait pas cette catégorie, elle est ajoutée. */
  var CAT_ANIMATION = { id: 'animation', label: 'Animation', color: '#2F7F73' };
  var PRODUITS_MANQUANTS = [
    { name: 'Vidéoprojecteur', cat: 'sono', price: 10, variants: ['Seul', 'Avec écran'], short: 'Vidéoproj.' },
    { name: "Livre d'or audio", cat: 'animation', price: 35, variants: ['Standard'], short: "Livre d'or" },
  ];

  /* ── catalogue : catégorie et produits manquants ────────────── */
  function completerCatalogue() {
    try {
      var cats = typeof window.getCats === 'function' ? window.getCats() : [];
      if (!cats.some(function (c) { return c.id === CAT_ANIMATION.id; })) {
        cats.push({ id: CAT_ANIMATION.id, label: CAT_ANIMATION.label, color: CAT_ANIMATION.color });
        localStorage.setItem('vespraCats', JSON.stringify(cats));
      }
      var prods = typeof window.getProds === 'function' ? window.getProds() : [];
      var ajout = false;
      PRODUITS_MANQUANTS.forEach(function (p) {
        if (!prods.some(function (x) { return x.name === p.name; })) { prods.push(p); ajout = true; }
      });
      if (ajout) localStorage.setItem('vespraProds', JSON.stringify(prods));
    } catch (e) {}
  }

  /* ── import ─────────────────────────────────────────────────── */
  function importer(bouton) {
    if (bouton) {
      bouton.disabled = true;
      bouton.textContent = 'Reprise en cours…';
    }

    return fetch(FICHIER, { headers: { accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (liste) {
        if (!Array.isArray(liste)) throw new Error('fichier');
        completerCatalogue();

        var R = window.R || [];
        var connus = {};
        R.forEach(function (r) { if (r && r.id) connus[String(r.id)] = true; });

        var ajoutees = 0;
        liste.forEach(function (r) {
          if (!r || !r.id || connus[r.id]) return;
          R.push(r);
          connus[r.id] = true;
          ajoutees++;
        });

        window.R = R;
        /* l'enregistrement dans le navigateur déclenche l'envoi au
           serveur, réservation par réservation : rien de plus à faire */
        localStorage.setItem('vespraR', JSON.stringify(R));
        if (typeof window.fbPutCfg === 'function') window.fbPutCfg();

        if (bouton) {
          bouton.textContent = ajoutees
            ? ajoutees + ' réservation' + (ajoutees > 1 ? 's' : '') + ' reprise' + (ajoutees > 1 ? 's' : '')
            : 'Planning déjà à jour';
        }

        setTimeout(function () {
          var b = document.querySelector('.vi-bandeau');
          if (b) b.remove();
          if (typeof window.nav === 'function') window.nav();
        }, bouton ? 1400 : 0);
        return ajoutees;
      })
      .catch(function () {
        if (bouton) {
          bouton.disabled = false;
          bouton.textContent = 'Reprise impossible — réessayer';
        }
        return -1;   /* échec : le bandeau proposera de réessayer */
      });
  }

  /* ── reprise automatique ─────────────────────────────────────
     Rien à cliquer : à la première ouverture du back-office, le planning
     Excel est repris tout seul. Le bandeau n'apparaît qu'en cas d'échec
     (fichier inaccessible, serveur injoignable), pour pouvoir réessayer.

     La reprise n'a lieu qu'une fois : ensuite, le planning porte déjà les
     réservations reprises, et elle ne se redéclenche pas. Une réservation
     supprimée à la main ne revient donc pas. */
  var CLE_FAIT = 'vespraImportExcel';
  var tentee = false;

  function reprendreSeul() {
    if (tentee) return;
    /* on attend que le planning soit chargé depuis le serveur, sans quoi
       on importerait par-dessus une liste encore vide */
    if (!Array.isArray(window.R)) return;
    tentee = true;

    var deja = window.R.some(function (r) { return r && String(r.id).indexOf(PREFIXE) === 0; });
    try { if (deja || localStorage.getItem(CLE_FAIT)) { marquer(); return; } } catch (e) {}

    importer(null).then(function (n) {
      if (!(n >= 0)) return;
      marquer();
      if (typeof window.nav === 'function') window.nav();
    });
  }

  function marquer() {
    try { localStorage.setItem(CLE_FAIT, '1'); } catch (e) {}
  }

  /* ── bandeau, en dernier recours ─────────────────────────────── */
  function bandeau() {
    var page = document.querySelector('main .page');
    if (!page || document.querySelector('.vi-bandeau')) return;
    if (window.page !== 'planning') return;

    var deja = (window.R || []).some(function (r) {
      return r && String(r.id).indexOf(PREFIXE) === 0;
    });
    if (deja) return;
    /* la reprise automatique a déjà eu lieu : plus rien à proposer */
    try { if (localStorage.getItem(CLE_FAIT)) return; } catch (e) {}
    if (!tentee) return;

    var bloc = document.createElement('div');
    bloc.className = 'vi-bandeau';
    bloc.style.cssText = 'display:flex;flex-wrap:wrap;align-items:center;gap:10px 16px;' +
      'margin:0 0 16px;padding:13px 16px;background:#fff;border:1px solid #eee8dc;' +
      'border-left:3px solid #C9A24B;border-radius:12px';
    bloc.innerHTML = '<span style="font:600 13.5px Inter;color:#4a4a44;flex:1;min-width:200px">' +
      'Les réservations 2026, 2027 et 2028 du fichier Excel peuvent être reprises dans le planning.</span>';

    var bt = document.createElement('button');
    bt.type = 'button';
    bt.textContent = 'Reprendre le planning Excel';
    bt.style.cssText = 'background:#1e3650;color:#fff;border:none;border-radius:999px;' +
      'padding:9px 18px;font:600 13px Inter;cursor:pointer';
    bt.addEventListener('click', function () { importer(bt); });
    bloc.appendChild(bt);

    page.insertBefore(bloc, page.firstChild);
  }

  function brancher() {
    /* le pont charge les réservations du serveur puis appelle nav() :
       c'est le moment où l'on sait ce que contient déjà le planning */
    if (typeof window.nav === 'function' && !window.nav._vi) {
      var naviguer = window.nav;
      var nouveau = function () {
        var res = naviguer.apply(this, arguments);
        reprendreSeul();
        setTimeout(bandeau, 0);
        return res;
      };
      nouveau._vi = true;
      window.nav = nouveau;
    }
    bandeau();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', brancher);
  else brancher();
})();
