/* ─────────────────────────────────────────────────────────────
   Application des prix modifiés depuis le back-office (/admin).

   Les prix restent écrits en dur dans les pages : c'est ce que voit
   un visiteur si ce script ne s'exécute pas, et c'est ce que lisent
   les moteurs de recherche. Ce script ne fait que remplacer ceux que
   vous avez modifiés depuis l'admin, sur la fiche produit comme dans
   le catalogue, pour que le prix affiché et le prix ajouté au devis
   soient toujours les mêmes.

   Nécessite prix-registre.js chargé avant lui.
   ───────────────────────────────────────────────────────────── */
(function () {
  var REGISTRE = window.VESPRA_PRIX_REGISTRE;
  if (!REGISTRE || !REGISTRE.length) return;

  /* nom de fichier de la page courante, y compris en URL « propre »
     (/produit-sonorisation → produit-sonorisation.html) */
  var page = (location.pathname.split('/').pop() || 'index.html');
  if (page.indexOf('.') === -1) page += '.html';

  var nombre = function (v) {
    var n = parseFloat(String(v).replace(',', '.').replace(/[^\d.]/g, ''));
    return isFinite(n) && n > 0 ? n : null;
  };

  /* le back-office charge ce fichier pour ses fonctions utilitaires, sans
     le chargeur de données : il n'y a alors rien à appliquer */
  if (typeof window.VESPRA_DONNEES !== 'function') return;

  window.VESPRA_DONNEES('produits')
    .then(function (items) {
      if (!Array.isArray(items)) return;
      var prix = {}, fiches = {}, nouveaux = [];
      items.forEach(function (it) {
        if (!it || !it.id) return;
        if (it.type === 'prix') {
          var v = nombre(it.prix);
          if (v) prix[it.id] = v;
        } else if (it.type === 'produit') {
          fiches[it.id] = it;
        } else {
          nouveaux.push(it);
        }
      });
      if (page === 'catalogue.html') appliquerCatalogue(prix, fiches, nouveaux);
      else { appliquerFiche(prix); appliquerFicheInfos(fiches); }
      appliquerMentions(prix);
    })
    .catch(function () { /* silencieux : les prix d'origine restent affichés */ });

  /* ── fiche produit : boutons de variante + prix principal ── */
  /* ── Options d'une fiche produit ──────────────────────────────────
     Les options (sacs de lestage, caisson de basse, maïs…) ont leur prix
     écrit à trois endroits : l'étiquette « + 45 € » à côté de la case,
     le calcul du prix affiché, et le montant ajouté au devis. Le tarif
     modifié depuis le back-office est publié ici, dans un point unique
     que la page consulte à chaque calcul.
     ─────────────────────────────────────────────────────────────────── */
  var PRIX_OPTIONS = {};
  window.VESPRA_OPT = function (champ, defaut) {
    var v = PRIX_OPTIONS[champ];
    return (v === undefined || v === null) ? defaut : v;
  };

  function appliquerOptions(prix) {
    var options = REGISTRE.filter(function (e) { return e.pg === page && e.opt; });
    if (!options.length) return;
    var change = false;

    options.forEach(function (e) {
      var np = prix[e.i];
      if (!np || !e.champ) return;
      PRIX_OPTIONS[e.champ] = np;
      change = true;

      /* l'étiquette de prix est le dernier élément de l'intitulé */
      var case_ = document.getElementById(e.champ);
      var label = case_ && case_.closest('label');
      var etiquette = label && label.lastElementChild;
      if (etiquette && /€|Inclus/.test(etiquette.textContent)) {
        etiquette.textContent = '+\u00a0' + np + '\u00a0€';
      }
    });

    /* on redemande à la page de recalculer, pour que le prix affiché et le
       montant du devis tiennent compte du nouveau tarif */
    if (change) {
      ['majPrixSono', 'updateInstallOption', 'updatePhotoboothOptions', 'majPrix'].forEach(function (f) {
        if (typeof window[f] === 'function') { try { window[f](); } catch (err) {} }
      });
    }
  }

  function appliquerFiche(prix) {
    appliquerOptions(prix);
    var entrees = REGISTRE.filter(function (e) { return e.pg === page && !e.opt; });
    if (!entrees.length) return;
    var btns = document.querySelectorAll('.prod-vbtn');
    var touche = false;

    entrees.forEach(function (e) {
      var np = prix[e.i];
      if (!np) return;

      if (e.vi >= 0) {
        var b = btns[e.vi];
        if (!b) return;
        var el = b.querySelector('.prod-vbtn-price');
        if (el) el.textContent = np + ' €';
        if (b.hasAttribute('data-price')) b.setAttribute('data-price', np);
        var oc = b.getAttribute('onclick');
        if (oc) {
          /* remplace le prix passé à selectVariant(this,'…',PRIX…) pour que
             le montant ajouté au devis suive le montant affiché */
          b.setAttribute('onclick', oc.replace(/(selectVariant\(this,\s*'(?:[^']*)'\s*,\s*)\d+(?:\.\d+)?/, '$1' + np));
        }
        touche = true;
      } else {
        majPrixPrincipal(np);
        touche = true;
      }
    });

    /* le prix principal reflète la variante sélectionnée à l'ouverture */
    if (touche && btns.length) {
      var actif = document.querySelector('.prod-vbtn.active') || btns[0];
      var t = actif && actif.querySelector('.prod-vbtn-price');
      var v = t && nombre(t.textContent);
      if (v) majPrixPrincipal(v);
    }
  }

  /* image, description et libellés de variante modifiés depuis l'admin */
  function appliquerFicheInfos(fiches) {
    var entree = REGISTRE.filter(function (e) { return e.pg === page && !e.opt; })[0];
    if (!entree) return;
    var f = fiches[entree.ci];
    if (!f) return;

    if (f.image) {
      var img = document.getElementById('prodMainImg');
      if (img) { img.src = f.image; img.removeAttribute('srcset'); }
    }
    if (f.variantes) {
      var labels = String(f.variantes).split('|');
      var btns = document.querySelectorAll('.prod-vbtn');
      labels.forEach(function (lab, i) {
        lab = lab.trim();
        var b = btns[i];
        if (!lab || !b) return;
        var n = b.querySelector('.prod-vbtn-name');
        if (n) n.textContent = lab;
        var oc = b.getAttribute('onclick');
        if (oc) b.setAttribute('onclick', oc.replace(/(selectVariant\(this,\s*')(?:[^']*)(')/, '$1' + lab.replace(/'/g, '') + '$2'));
      });
    }
  }

  function majPrixPrincipal(v) {
    var disp = document.getElementById('prodPriceDisplay');
    if (!disp) return;
    var small = disp.querySelector('small');
    disp.innerHTML = v + ' €' + (small ? ' ' + small.outerHTML : '');
  }

  /* ── prix cités dans le texte des pages ──────────────────────────────
     Articles, pages de villes, FAQ, paragraphes des fiches : « le Pack
     Vespra va de 70 € à 150 € ». Chaque mention a été repérée à l'avance
     avec le texte qui la précède, ce qui permet de ne remplacer que le bon
     montant. Un montant dont le contexte ne correspond plus exactement
     n'est pas touché : mieux vaut un prix non mis à jour qu'un prix faux
     au mauvais endroit. */
  function normTexte(t) {
    /* même normalisation que celle qui a servi à établir le registre :
       accents décomposés puis tout caractère non ASCII retiré (tirets
       cadratins, symbole €…), minuscules, espaces réduits */
    return String(t).normalize('NFD').replace(/[^\x00-\x7F]/g, '')
      .toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function appliquerMentions(prix) {
    var toutes = window.VESPRA_MENTIONS;
    if (!toutes) return;
    var entree = null;
    for (var i = 0; i < toutes.length; i++) if (toutes[i].pg === page) { entree = toutes[i]; break; }
    if (!entree) return;

    var aFaire = entree.m.filter(function (m) { return prix[m.id] && prix[m.id] !== m.v; });
    if (!aFaire.length) return;

    /* noeuds texte de la page, hors zones déjà gérées plus haut */
    var IGNORE = '.prod-vbtn, #prodPriceDisplay, .prod-price, .vm-info, #vmSelect, script, style';
    var noeuds = [];
    var it = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = it.nextNode())) {
      if (!n.nodeValue || n.nodeValue.indexOf('\u20AC') === -1) continue;
      if (n.parentElement && n.parentElement.closest && n.parentElement.closest(IGNORE)) continue;
      noeuds.push(n);
    }

    /* Deux passes : on repère d'abord TOUS les emplacements, puis on
       remplace. Sinon un montant déjà remplacé modifierait le texte qui
       sert à reconnaître le suivant. */
    var cibles = [];
    aFaire.forEach(function (m) {
      var motif = new RegExp('(^|[^\\d])' + m.v + '(\\s|\u00a0)*\u20AC');
      var trouves = [];
      noeuds.forEach(function (nd) {
        var t = nd.nodeValue;
        var res = motif.exec(t);
        if (!res) return;
        var pos = res.index + res[1].length;
        var avant = normTexte(t.slice(Math.max(0, pos - 34), pos)).slice(-24);
        if (avant !== m.s) return;
        trouves.push({ noeud: nd, pos: pos, longueur: res[0].length - res[1].length, prix: prix[m.id] });
      });
      /* un seul emplacement possible, sinon on s'abstient */
      if (trouves.length === 1) cibles.push(trouves[0]);
    });

    /* de la fin vers le début dans chaque nœud, pour que les positions
       déjà calculées restent valables */
    cibles.sort(function (a, b) { return b.pos - a.pos; });
    cibles.forEach(function (c) {
      var val = c.noeud.nodeValue;
      var morceau = val.slice(c.pos, c.pos + c.longueur).replace(/^\d+/, String(c.prix));
      c.noeud.nodeValue = val.slice(0, c.pos) + morceau + val.slice(c.pos + c.longueur);
    });
  }

  /* ── catalogue : tableau PRODUCTS (cartes, fenêtre produit, devis) ── */
  function appliquerCatalogue(prix, fiches, nouveaux) {
    var P = window.PRODUCTS;
    if (!P) return;
    var modifies = {};

    /* fiches modifiées : image, description, libellés de variante */
    Object.keys(fiches).forEach(function (id) {
      var f = fiches[id], prod = null;
      for (var k = 0; k < P.length; k++) if (P[k].id === id) { prod = P[k]; break; }
      if (!prod) return;
      if (f.image) prod.img = f.image;
      if (f.description) prod.desc = f.description;
      if (f.variantes && prod.variants) {
        String(f.variantes).split('|').forEach(function (lab, i) {
          lab = lab.trim();
          if (lab && prod.variants[i]) prod.variants[i].label = lab;
        });
      }
    });

    REGISTRE.forEach(function (e) {
      var np = prix[e.i];
      if (!np) return;
      var prod = null;
      for (var k = 0; k < P.length; k++) if (P[k].id === e.ci) { prod = P[k]; break; }
      if (!prod) return;
      if (e.cvi >= 0 && prod.variants && prod.variants[e.cvi]) {
        prod.variants[e.cvi].price = np;
        modifies[prod.id] = true;
      } else {
        prod.price = np;
      }
    });

    /* « à partir de » sur la carte = variante la moins chère, recalculé
       uniquement pour les produits dont un prix a été modifié */
    P.forEach(function (prod) {
      if (!modifies[prod.id] || !prod.variants || !prod.variants.length) return;
      prod.price = Math.min.apply(null, prod.variants.map(function (v) { return v.price; }));
    });

    /* produits entièrement nouveaux, créés depuis l'admin */
    var connus = {};
    P.forEach(function (p) { connus[p.id] = true; });
    nouveaux.forEach(function (it) {
      if (!it.nom || connus['admin-' + it.id]) return;
      P.push({
        id: 'admin-' + it.id,
        cat: it.categorie || 'Autre',
        name: it.nom,
        price: nombre(it.prix) || 0,
        desc: it.description || '',
        img: it.image || '',
        page: null,
      });
    });

    if (typeof applyFilters === 'function') applyFilters();
    else if (typeof renderGrid === 'function') renderGrid(P);
  }
})();
