/* ─────────────────────────────────────────────────────────────
   En-tête : effet verre dépoli suspendu pendant l'ouverture du menu.

   L'en-tête du site est semi-transparent et floute ce qui passe
   derrière lui. C'est joli au défilement, mais quand le menu burger
   s'ouvre juste en dessous, les deux surfaces translucides se
   superposent et le menu devient difficile à lire.

   Ce script surveille l'ouverture du menu et pose la classe
   « menu-ouvert » sur l'en-tête : le temps que le menu reste ouvert,
   l'en-tête devient opaque. Dès la fermeture, l'effet revient.

   Il n'y a rien à appeler : le script se branche tout seul sur le
   menu existant, quelle que soit la page.
   ───────────────────────────────────────────────────────────── */
(function () {
  function demarrer() {
    var nav = document.querySelector('.nav');
    var liens = document.getElementById('navLinks');
    if (!nav || !liens) return;

    var style = document.createElement('style');
    style.textContent = [
      /* menu ouvert : en-tête et panneau entièrement opaques */
      '.nav.menu-ouvert{',
      '  background:#fff!important;',
      '  -webkit-backdrop-filter:none!important;backdrop-filter:none!important;',
      '  border-bottom:1px solid var(--g4,#E6E9F0)!important;',
      '  box-shadow:none!important;',
      '}',
      /* Le panneau couvre tout l'écran : une fois ouvert, le site ne doit
         plus réapparaître en bas. Les coordonnées, elles, restent juste
         sous le bouton « Réserver » — poussées tout en bas (margin-top:auto),
         elles laissaient un grand vide blanc au milieu du menu. L'espace
         libre est donc rejeté après elles, au bas du panneau. */
      '@media(max-width:960px){',
      '  .nav-links{height:calc(100dvh - var(--vp-entete,60px))!important;',
      '    min-height:calc(100dvh - var(--vp-entete,60px))!important;',
      '    max-height:none!important;padding-bottom:28px!important}',
      '  .nav-menu-foot{margin-top:18px!important}',
      '}',
      '.nav-links.open{',
      '  background:#fff!important;',
      '  -webkit-backdrop-filter:none!important;backdrop-filter:none!important;',
      '  border-bottom:1px solid var(--g4,#E6E9F0)!important;',
      '  box-shadow:0 10px 24px rgba(12,15,20,.10)!important;',
      '}',
    ].join('');
    document.head.appendChild(style);

    /* La hauteur réelle de l'en-tête varie d'une page et d'une largeur à
       l'autre : on la mesure plutôt que de la supposer, sans quoi le
       panneau dépasse du bas de l'écran ou s'arrête trop tôt. */
    function mesurer() {
      /* on mesure l'endroit où le panneau commence réellement, et non la
         hauteur de l'en-tête : un bandeau d'annonce, ajouté parfois après
         l'affichage, décale le tout vers le bas. Le panneau ouvert dit
         lui-même où il commence ; sinon on se rabat sur le bas de
         l'en-tête. */
      var haut = liens.classList.contains('open')
        ? liens.getBoundingClientRect().top
        : nav.getBoundingClientRect().bottom;
      document.documentElement.style.setProperty('--vp-entete', Math.max(0, Math.round(haut)) + 'px');
    }
    mesurer();
    window.addEventListener('resize', mesurer);
    window.addEventListener('scroll', function () {
      if (liens.classList.contains('open')) mesurer();
    }, { passive: true });
    if (window.ResizeObserver) new ResizeObserver(mesurer).observe(nav);
    /* un bandeau d'annonce peut arriver après l'affichage et tout décaler :
       on remesure quand la page change au-dessus de l'en-tête */
    if (window.MutationObserver) {
      new MutationObserver(mesurer).observe(document.body, { childList: true });
    }

    function majuscule() {
      var ouvert = liens.classList.contains('open');
      if (ouvert) { mesurer(); requestAnimationFrame(mesurer); }
      nav.classList.toggle('menu-ouvert', ouvert);
      /* le menu peut aussi être refermé en cliquant à côté : on remet
         alors le défilement de la page, que la fermeture n'annulait pas */
      if (!ouvert) {
        document.body.style.overflow = '';
        var bt = document.querySelector('.nav-toggle');
        if (bt) { bt.classList.remove('open'); bt.setAttribute('aria-expanded', 'false'); }
      }
    }

    new MutationObserver(majuscule).observe(liens, { attributes: true, attributeFilter: ['class'] });
    majuscule();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})();
