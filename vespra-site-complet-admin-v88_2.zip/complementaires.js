/* ─────────────────────────────────────────────────────────────
   Produits complémentaires : deux cartes sur téléphone, trois sur
   tablette, quatre sur grand écran.

   Chaque fiche produit propose deux produits complémentaires choisis à
   la main : c'est le bon nombre sur téléphone, où les cartes s'affichent
   deux par ligne. Sur un écran large, la même ligne peut en accueillir
   quatre sans rien serrer. Les emplacements manquants sont donc complétés
   ici, en priorité par des produits de la même catégorie.

   Les quatre cartes sont toujours présentes dans la page : c'est la
   feuille de style qui n'en montre que 2, 3 ou 4 selon la largeur de
   l'écran, afin qu'elles tiennent toujours sur une seule ligne.

   Les deux cartes d'origine ne sont jamais touchées : les nouvelles sont
   fabriquées en recopiant l'une d'elles, et héritent ainsi exactement de
   la même présentation.

   Nécessite prix-registre.js (window.VESPRA_PRODUITS) chargé avant lui.
   ───────────────────────────────────────────────────────────── */
(function () {
  function demarrer() {
    var grille = document.querySelector('.related-grid');
    var produits = window.VESPRA_PRODUITS;
    if (!grille || !produits || !produits.length) return;

    var cartes = grille.querySelectorAll('.rel-card');
    if (!cartes.length || cartes.length >= 4) return;

    /* page courante et produits déjà proposés : à ne pas reproposer */
    var page = (location.pathname.split('/').pop() || 'index.html');
    if (page.indexOf('.') === -1) page += '.html';
    var deja = {};
    deja[page] = true;
    Array.prototype.forEach.call(cartes, function (c) {
      deja[(c.getAttribute('href') || '').split('/').pop()] = true;
    });

    var actuel = null;
    for (var i = 0; i < produits.length; i++) {
      if (produits[i].page === page) { actuel = produits[i]; break; }
    }

    /* d'abord la même catégorie, puis le reste, dans l'ordre du catalogue */
    var libres = produits.filter(function (p) {
      return p && p.page && !deja[p.page];
    });
    if (actuel) {
      libres.sort(function (a, b) {
        var sa = a.cat === actuel.cat ? 0 : 1;
        var sb = b.cat === actuel.cat ? 0 : 1;
        return sa - sb;
      });
    }

    var manque = 4 - cartes.length;
    var modele = cartes[cartes.length - 1];

    libres.slice(0, manque).forEach(function (p) {
      var c = modele.cloneNode(true);
      c.setAttribute('href', p.page);

      var img = c.querySelector('.rel-img');
      if (img && p.img) {
        img.setAttribute('src', p.img);
        img.setAttribute('alt', p.nom || '');
        img.removeAttribute('srcset');
      }

      texte(c, '.rel-cat', p.cat || '');
      texte(c, '.rel-title', p.nom || '');
      texte(c, '.rel-why', accroche(p));

      var prix = c.querySelector('.rel-price');
      if (prix) {
        var multi = p.variantes && p.variantes.length > 1;
        prix.innerHTML = (multi ? '<span class="rel-from">À partir de</span>' : '') +
                         (p.prix != null ? p.prix + ' €' : 'Sur devis');
      }

      grille.appendChild(c);
    });

    function texte(racine, sel, val) {
      var el = racine.querySelector(sel);
      if (el) el.textContent = val;
    }

    /* une ligne courte tirée de la description du produit */
    function accroche(p) {
      var d = String(p.desc || '').trim();
      if (!d) return 'À découvrir dans le catalogue';
      var pt = d.indexOf('.');
      if (pt > 20) d = d.slice(0, pt);
      if (d.length > 58) d = d.slice(0, 55).replace(/\s+\S*$/, '') + '…';
      return d;
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})();
